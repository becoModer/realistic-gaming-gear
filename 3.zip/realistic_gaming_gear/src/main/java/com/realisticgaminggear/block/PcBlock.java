package com.realisticgaminggear.block;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A prebuilt gaming PC.
 * <ul>
 *   <li>Right click: press the power button. The fans spin and the RGB lights up (or everything stops).</li>
 *   <li>Sneak + right click with an empty hand: rotate the PC 90 degrees.</li>
 *   <li>Powering the PC on or off also switches every {@link MonitorBlock} within
 *       {@value #LINK_RADIUS} blocks (horizontally) the same way, so the monitors boot up with a
 *       new wallpaper when the PC starts.</li>
 * </ul>
 * A newly placed PC is off.
 */
public class PcBlock extends GearBlock {
    /** Monitors up to this many blocks away (horizontally) follow the PC's power. */
    public static final int LINK_RADIUS = 5;

    public PcBlock(Properties properties, double[] box) {
        super(properties, box, false, SoundEvents.WOODEN_BUTTON_CLICK_ON);
    }

    /** A PC is a solid block: you cannot walk through it. */
    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return getShape(state, level, pos, context);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND || !player.getItemInHand(hand).isEmpty()) {
            return InteractionResult.PASS;
        }
        if (player.isShiftKeyDown()) {
            rotate(state, level, pos);
        } else if (!level.isClientSide) {
            setPower(level, pos, state, !state.getValue(LIT));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Server side: turns the PC on or off and makes the monitors around it follow. */
    public static void setPower(Level level, BlockPos pos, BlockState state, boolean on) {
        level.setBlock(pos, state.setValue(LIT, on), 3);
        level.playSound(null, pos, on ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE,
                SoundSource.BLOCKS, 0.35F, on ? 1.6F : 1.3F);

        BlockPos from = pos.offset(-LINK_RADIUS, -2, -LINK_RADIUS);
        BlockPos to = pos.offset(LINK_RADIUS, 3, LINK_RADIUS);
        for (BlockPos mutable : BlockPos.betweenClosed(from, to)) {
            BlockPos target = mutable.immutable();
            BlockState other = level.getBlockState(target);
            if (other.getBlock() instanceof MonitorBlock monitor) {
                monitor.setPowered(other, level, target, on);
            }
        }
    }
}
