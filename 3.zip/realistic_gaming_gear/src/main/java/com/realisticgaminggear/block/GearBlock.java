package com.realisticgaminggear.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A small desk item (mouse, keyboard, monitor, accessory...).
 * <p>
 * Model convention: with FACING = NORTH the "front" of the item (the edge nearest the
 * person sitting at the desk, i.e. the screen of a monitor) points to the north. The item
 * must stand on a block whose top face is full (e.g. a desk).
 * <ul>
 *   <li>Right click: rotate 90 degrees and play a click sound.</li>
 *   <li>Sneak + right click: toggle RGB / screen / lamp (RGB variants only).</li>
 * </ul>
 */
public class GearBlock extends HorizontalDirectionalBlock {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    /** Indexed by {@link Direction#get2DDataValue()}. */
    protected final VoxelShape[] shapes;
    protected final boolean rgb;
    protected final SoundEvent clickSound;

    /**
     * @param box north-facing box in 1/16 block units: {x1, y1, z1, x2, y2, z2}
     */
    public GearBlock(Properties properties, double[] box, boolean rgb, SoundEvent clickSound) {
        super(properties);
        this.rgb = rgb;
        this.clickSound = clickSound;
        this.shapes = makeShapes(box);

        registerDefaultState(stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(LIT, rgb));
    }

    /**
     * Builds the four rotated shapes (indexed by 2D data value) of the union of the given
     * north-facing boxes.
     */
    protected static VoxelShape[] makeShapes(double[]... boxes) {
        VoxelShape[] result = new VoxelShape[4];
        double[][] current = new double[boxes.length][];
        for (int i = 0; i < boxes.length; i++) {
            current[i] = boxes[i].clone();
        }
        // Clockwise steps from NORTH: NORTH 0, EAST 1, SOUTH 2, WEST 3
        Direction[] clockwise = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        for (Direction dir : clockwise) {
            VoxelShape shape = Shapes.empty();
            for (int i = 0; i < current.length; i++) {
                double[] b = current[i];
                shape = Shapes.or(shape, Block.box(b[0], b[1], b[2], b[3], b[4], b[5]));
                current[i] = rotateClockwise(b);
            }
            result[dir.get2DDataValue()] = shape;
        }
        return result;
    }

    /** Rotates a box 90 degrees clockwise (seen from above) around the block centre. */
    private static double[] rotateClockwise(double[] b) {
        // (x, z) -> (16 - z, x)
        return new double[]{16 - b[5], b[1], b[0], 16 - b[2], b[4], b[3]};
    }

    public boolean isRgb() {
        return rgb;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIT);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState()
                .setValue(FACING, context.getHorizontalDirection().getOpposite())
                .setValue(LIT, rgb);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapes[state.getValue(FACING).get2DDataValue()];
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction == Direction.DOWN && !state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND || !player.getItemInHand(hand).isEmpty()) {
            return InteractionResult.PASS;
        }
        if (player.isShiftKeyDown() && rgb) {
            toggleLit(state, level, pos);
        } else {
            rotate(state, level, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    protected void toggleLit(BlockState state, Level level, BlockPos pos) {
        boolean nowLit = !state.getValue(LIT);
        level.setBlock(pos, state.setValue(LIT, nowLit), 3);
        level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS,
                0.6F, nowLit ? 1.2F : 0.9F);
    }

    protected void rotate(BlockState state, Level level, BlockPos pos) {
        level.setBlock(pos, state.setValue(FACING, state.getValue(FACING).getClockWise()), 3);
        level.playSound(null, pos, clickSound, SoundSource.BLOCKS,
                0.5F, 0.9F + level.random.nextFloat() * 0.3F);
    }
}
