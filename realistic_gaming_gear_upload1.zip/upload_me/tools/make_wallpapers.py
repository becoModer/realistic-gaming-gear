#!/usr/bin/env python3
"""
Turns the wallpaper videos into animated Minecraft textures with a Windows-11-style
desktop (taskbar, a few apps, desktop icons) drawn on top.

Usage:   python3 tools/make_wallpapers.py video0.mp4 video1.mp4 video2.mp4 video3.mp4
Needs:   ffmpeg on PATH and Pillow.
Output:  tools/video_textures/wallpaper_0..3.png (+ .png.mcmeta)

gen_assets.py copies these into the mod. All icons are generic / invented (no real logos).
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

W, H = 128, 72          # texture frame size (16:9)
FPS = 10                # frames per second  -> frametime 2 ticks
SS = 4                  # supersampling factor for the UI overlay
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "video_textures")


def font(size):
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def build_overlay():
    """Windows-11-like UI, drawn at SS x resolution then downsampled with proper alpha."""
    w, h = W * SS, H * SS
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    s = SS

    # ---- taskbar -------------------------------------------------------------
    bar_h = 7 * s
    d.rectangle((0, h - bar_h, w, h), fill=(18, 20, 30, 225))
    d.line((0, h - bar_h, w, h - bar_h), fill=(255, 255, 255, 40), width=1)

    # centered row of icons: launcher, search, 5 apps
    icon = 5 * s
    gap = 2 * s
    items = ["start", "search", "folder", "globe", "music", "game", "gear"]
    widths = [icon, 14 * s] + [icon] * 5
    total = sum(widths) + gap * (len(items) - 1)
    x = (w - total) // 2
    cy = h - bar_h // 2
    for name, iw in zip(items, widths):
        draw_icon(d, name, x, cy - icon // 2, iw, icon, s)
        x += iw + gap
    # little "active app" underline under the browser icon
    # (index 3 -> x position recomputed)
    x = (w - total) // 2 + sum(widths[:3]) + gap * 3
    d.rounded_rectangle((x + 1 * s, h - 1 * s - 1, x + icon - 1 * s, h - 1), radius=1, fill=(120, 190, 255, 255))

    # ---- system tray (right side) -----------------------------------------------
    tx = w - 30 * s
    d.rounded_rectangle((tx, cy - 1 * s, tx + 3 * s, cy + 1 * s), radius=1, fill=(235, 235, 245, 230))  # wifi-ish
    d.rounded_rectangle((tx + 5 * s, cy - 1 * s, tx + 6 * s, cy + 1 * s), radius=1, fill=(235, 235, 245, 230))
    d.rounded_rectangle((tx + 8 * s, cy - 1 * s, tx + 13 * s, cy + 1 * s), radius=1,
                        outline=(235, 235, 245, 230), width=1)  # battery
    d.rectangle((tx + 9 * s, cy - 1 * s + 1, tx + 12 * s, cy + 1 * s - 1), fill=(120, 230, 150, 230))
    f = font(int(2.9 * s))
    d.text((w - 15 * s, cy - 3.4 * s), "12:00", font=f, fill=(245, 245, 250, 255))
    f2 = font(int(2.2 * s))
    d.text((w - 15 * s, cy + 0.2 * s), "22/11", font=f2, fill=(200, 200, 215, 255))

    # ---- desktop icons (top-left) -----------------------------------------------
    labels = [("bin", "Bin"), ("pc", "This PC"), ("games", "Games")]
    lf = font(int(2.3 * s))
    y = 4 * s
    for kind, label in labels:
        ix = 5 * s
        draw_desktop_icon(d, kind, ix, y, 8 * s, s)
        tw = d.textlength(label, font=lf)
        d.text((ix + 4 * s - tw / 2, y + 8.6 * s), label, font=lf, fill=(255, 255, 255, 235))
        y += 14 * s

    # premultiplied resize avoids dark fringes around translucent edges
    small = img.convert("RGBa").resize((W, H), Image.LANCZOS).convert("RGBA")
    return small


def draw_icon(d, name, x, y, iw, ih, s):
    """Taskbar icons (all invented, generic shapes)."""
    if name == "start":  # blue rounded launcher with a sparkle
        d.rounded_rectangle((x, y, x + iw, y + ih), radius=int(1.2 * s), fill=(70, 140, 255, 255))
        cx, cy = x + iw / 2, y + ih / 2
        r = 1.7 * s
        d.polygon([(cx, cy - r), (cx + r * 0.35, cy - r * 0.35), (cx + r, cy), (cx + r * 0.35, cy + r * 0.35),
                   (cx, cy + r), (cx - r * 0.35, cy + r * 0.35), (cx - r, cy), (cx - r * 0.35, cy - r * 0.35)],
                  fill=(255, 255, 255, 255))
    elif name == "search":  # rounded search pill with a lens and a text hint
        d.rounded_rectangle((x, y, x + iw, y + ih), radius=int(2.5 * s), fill=(255, 255, 255, 38),
                            outline=(255, 255, 255, 70))
        d.ellipse((x + 1.3 * s, y + 1.3 * s, x + 3.2 * s, y + 3.2 * s), outline=(235, 235, 245, 255), width=int(s * 0.5))
        d.line((x + 3 * s, y + 3 * s, x + 3.9 * s, y + 3.9 * s), fill=(235, 235, 245, 255), width=int(s * 0.5))
        d.rounded_rectangle((x + 5.5 * s, y + 2.1 * s, x + 12 * s, y + 2.9 * s), radius=1, fill=(210, 210, 225, 150))
    elif name == "folder":
        d.rounded_rectangle((x, y + 1 * s, x + iw, y + ih), radius=int(0.8 * s), fill=(250, 200, 70, 255))
        d.rounded_rectangle((x, y, x + 2.4 * s, y + 1.6 * s), radius=int(0.5 * s), fill=(235, 170, 40, 255))
        d.rectangle((x, y + 2 * s, x + iw, y + ih), fill=(255, 215, 100, 255))
    elif name == "globe":
        d.ellipse((x, y, x + iw, y + ih), fill=(40, 150, 240, 255))
        d.ellipse((x + 1.2 * s, y + 0.2 * s, x + iw - 1.2 * s, y + ih - 0.2 * s), outline=(255, 255, 255, 200), width=int(s * 0.4))
        d.line((x, y + ih / 2, x + iw, y + ih / 2), fill=(255, 255, 255, 200), width=int(s * 0.4))
        d.line((x + iw / 2, y, x + iw / 2, y + ih), fill=(255, 255, 255, 200), width=int(s * 0.4))
    elif name == "music":
        d.rounded_rectangle((x, y, x + iw, y + ih), radius=int(1.2 * s), fill=(220, 70, 160, 255))
        d.ellipse((x + 1.0 * s, y + 3 * s, x + 2.4 * s, y + 4.4 * s), fill=(255, 255, 255, 255))
        d.ellipse((x + 2.9 * s, y + 2.4 * s, x + 4.3 * s, y + 3.8 * s), fill=(255, 255, 255, 255))
        d.line((x + 2.3 * s, y + 3.6 * s, x + 2.3 * s, y + 1.0 * s), fill=(255, 255, 255, 255), width=int(s * 0.4))
        d.line((x + 4.2 * s, y + 3.0 * s, x + 4.2 * s, y + 0.6 * s), fill=(255, 255, 255, 255), width=int(s * 0.4))
        d.line((x + 2.3 * s, y + 1.0 * s, x + 4.2 * s, y + 0.6 * s), fill=(255, 255, 255, 255), width=int(s * 0.5))
    elif name == "game":
        d.rounded_rectangle((x, y, x + iw, y + ih), radius=int(1.2 * s), fill=(60, 190, 100, 255))
        d.rounded_rectangle((x + 0.8 * s, y + 1.6 * s, x + iw - 0.8 * s, y + ih - 1.2 * s), radius=int(1.1 * s),
                            fill=(20, 40, 30, 255))
        d.line((x + 1.8 * s, y + 3 * s, x + 2.8 * s, y + 3 * s), fill=(255, 255, 255, 255), width=int(s * 0.4))
        d.line((x + 2.3 * s, y + 2.5 * s, x + 2.3 * s, y + 3.5 * s), fill=(255, 255, 255, 255), width=int(s * 0.4))
        d.ellipse((x + 3.2 * s, y + 2.7 * s, x + 3.8 * s, y + 3.3 * s), fill=(255, 90, 90, 255))
    elif name == "gear":
        import math
        cx, cy = x + iw / 2, y + ih / 2
        d.ellipse((cx - 2.2 * s, cy - 2.2 * s, cx + 2.2 * s, cy + 2.2 * s), fill=(185, 190, 205, 255))
        for k in range(8):
            a = k * math.pi / 4
            d.rectangle((cx + math.cos(a) * 2.4 * s - 0.5 * s, cy + math.sin(a) * 2.4 * s - 0.5 * s,
                         cx + math.cos(a) * 2.4 * s + 0.5 * s, cy + math.sin(a) * 2.4 * s + 0.5 * s),
                        fill=(185, 190, 205, 255))
        d.ellipse((cx - 0.9 * s, cy - 0.9 * s, cx + 0.9 * s, cy + 0.9 * s), fill=(40, 44, 60, 255))


def draw_desktop_icon(d, kind, x, y, size, s):
    """Desktop icons (generic shapes, 8 px)."""
    if kind == "bin":
        d.polygon([(x + 1.5 * s, y + 2 * s), (x + 6.5 * s, y + 2 * s), (x + 5.8 * s, y + 7.5 * s), (x + 2.2 * s, y + 7.5 * s)],
                  fill=(190, 200, 215, 235), outline=(255, 255, 255, 255))
        d.rectangle((x + 1 * s, y + 1.2 * s, x + 7 * s, y + 2 * s), fill=(230, 235, 245, 255))
        d.rectangle((x + 3 * s, y + 0.5 * s, x + 5 * s, y + 1.2 * s), fill=(230, 235, 245, 255))
    elif kind == "pc":
        d.rounded_rectangle((x + 0.5 * s, y + 1 * s, x + 7.5 * s, y + 5.6 * s), radius=int(0.5 * s),
                            fill=(60, 140, 230, 255), outline=(235, 240, 250, 255))
        d.rectangle((x + 3.2 * s, y + 5.6 * s, x + 4.8 * s, y + 6.6 * s), fill=(220, 225, 235, 255))
        d.rectangle((x + 2 * s, y + 6.6 * s, x + 6 * s, y + 7.2 * s), fill=(220, 225, 235, 255))
    elif kind == "games":
        d.rounded_rectangle((x + 0.2 * s, y + 1.2 * s, x + 7.8 * s, y + 7 * s), radius=int(0.8 * s),
                            fill=(250, 200, 70, 255))
        d.rounded_rectangle((x + 0.2 * s, y + 0.5 * s, x + 3 * s, y + 1.8 * s), radius=int(0.4 * s),
                            fill=(235, 170, 40, 255))
        d.ellipse((x + 2.6 * s, y + 3 * s, x + 5.4 * s, y + 5.8 * s), fill=(60, 190, 100, 255))


def extract_frames(video, tmp):
    """-> list of PIL images, W x H, at FPS."""
    for f in os.listdir(tmp):
        os.remove(os.path.join(tmp, f))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video,
                    "-vf", "fps=%d,scale=%d:%d:flags=lanczos" % (FPS, W, H),
                    os.path.join(tmp, "f%04d.png")], check=True)
    names = sorted(os.listdir(tmp))
    return [Image.open(os.path.join(tmp, n)).convert("RGBA") for n in names]


def main(videos):
    if shutil.which("ffmpeg") is None:
        sys.exit("ffmpeg not found")
    overlay = build_overlay()
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):
        os.remove(os.path.join(OUT, f))
    overlay.save(os.path.join(OUT, "_ui_preview.png"))
    total = 0
    with tempfile.TemporaryDirectory() as tmp:
        for i, video in enumerate(videos):
            frames = extract_frames(video, tmp)
            sheet = Image.new("RGBA", (W, H * len(frames)))
            for k, fr in enumerate(frames):
                sheet.paste(Image.alpha_composite(fr, overlay), (0, k * H))
            path = os.path.join(OUT, "wallpaper_%d.png" % i)
            sheet.save(path, optimize=True)
            with open(path + ".mcmeta", "w") as fh:
                json.dump({"animation": {"width": W, "height": H, "frametime": 2, "interpolate": False}}, fh)
            total += len(frames)
            print("wallpaper_%d: %d frames, %d KB" % (i, len(frames), os.path.getsize(path) // 1024))
    print("total frames:", total)


if __name__ == "__main__":
    if len(sys.argv) != 5:
        sys.exit(__doc__)
    main(sys.argv[1:])
