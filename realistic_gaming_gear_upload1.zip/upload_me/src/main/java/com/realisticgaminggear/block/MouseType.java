package com.realisticgaminggear.block;

import com.realisticgaminggear.RealisticGamingGear;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;

/** The mouse that currently sits on a mousepad. The serialized names match the mouse_* block names. */
public enum MouseType implements StringRepresentable {
    NONE("none", false),
    BASIC("basic", false),
    RGB("rgb", true),
    LIGHTWEIGHT("lightweight", false),
    PRO("pro", false),
    WIRELESS("wireless", false),
    ULTRA("ultra", true);

    private final String id;
    private final boolean rgb;

    MouseType(String id, boolean rgb) {
        this.id = id;
        this.rgb = rgb;
    }

    @Override
    public String getSerializedName() {
        return id;
    }

    public boolean isRgb() {
        return rgb;
    }

    /** The mouse item for this type (empty for NONE). */
    public ItemStack toStack() {
        if (this == NONE) {
            return ItemStack.EMPTY;
        }
        Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(RealisticGamingGear.MODID, "mouse_" + id));
        return item == null ? ItemStack.EMPTY : new ItemStack(item);
    }

    /** Returns the mouse type for one of our mouse items, or null for any other item. */
    @Nullable
    public static MouseType fromItem(Item item) {
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
        if (key == null || !RealisticGamingGear.MODID.equals(key.getNamespace())
                || !key.getPath().startsWith("mouse_")) {
            return null;
        }
        String wanted = key.getPath().substring("mouse_".length());
        for (MouseType type : values()) {
            if (type != NONE && type.id.equals(wanted)) {
                return type;
            }
        }
        return null;
    }
}
