package com.realisticgaminggear.block;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A mousepad that can carry a mouse.
 * <ul>
 *   <li>Right click with a mouse item: put the mouse on the pad (or swap it for another one).</li>
 *   <li>Right click with an empty hand: rotate the pad (and the mouse with it).</li>
 *   <li>Sneak + right click with an empty hand: toggle RGB (RGB pad or RGB mouse).</li>
 *   <li>Breaking the pad drops the pad and the mouse.</li>
 * </ul>
 */
public class MousePadBlock extends GearBlock {
    public static final EnumProperty<MouseType> MOUSE = EnumProperty.create("mouse", MouseType.class);

    private static final double[] PAD_BOX = {1, 0, 2, 15, 1, 14};
    /** Where the mouse sits on the pad (north-facing); matches the generated *_onpad models. */
    private static final double[] MOUSE_BOX = {8.5, 1, 5, 12.5, 3.4, 11};

    private final VoxelShape[] shapesWithMouse = makeShapes(PAD_BOX, MOUSE_BOX);

    public MousePadBlock(Properties properties, boolean rgb) {
        super(properties, PAD_BOX, rgb, SoundEvents.WOOL_PLACE);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIT, MOUSE);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape[] source = state.getValue(MOUSE) == MouseType.NONE ? shapes : shapesWithMouse;
        return source[state.getValue(FACING).get2DDataValue()];
    }

    private boolean rgbCapable(BlockState state) {
        return rgb || state.getValue(MOUSE).isRgb();
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }

        ItemStack held = player.getItemInHand(hand);
        MouseType heldType = MouseType.fromItem(held.getItem());
        MouseType current = state.getValue(MOUSE);

        if (heldType != null) {
            if (heldType == current) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide) {
                BlockState next = state
                        .setValue(MOUSE, heldType)
                        .setValue(LIT, rgb || heldType.isRgb());
                level.setBlock(pos, next, 3);
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                if (current != MouseType.NONE) {
                    ItemStack old = current.toStack();
                    if (!old.isEmpty() && !player.getInventory().add(old)) {
                        player.drop(old, false);
                    }
                }
            }
            level.playSound(null, pos, SoundEvents.STONE_BUTTON_CLICK_ON, SoundSource.BLOCKS, 0.5F, 1.1F);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        if (player.isShiftKeyDown() && rgbCapable(state)) {
            toggleLit(state, level, pos);
        } else {
            rotate(state, level, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
