package com.realisticgaminggear.block;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * A monitor. Sneak + right click turns the screen on or off.
 * <p>
 * The screen shows one of {@link #WALLPAPER_COUNT} animated wallpapers (with a desktop on top).
 * While the monitor stays on, the same wallpaper keeps playing; every time it is turned on again,
 * a different wallpaper is picked. A freshly placed monitor starts on with a random wallpaper.
 */
public class MonitorBlock extends GearBlock {
    public static final int WALLPAPER_COUNT = 4;
    public static final IntegerProperty WALLPAPER = IntegerProperty.create("wallpaper", 0, WALLPAPER_COUNT - 1);

    public MonitorBlock(Properties properties, double[] box) {
        super(properties, box, true, SoundEvents.WOODEN_BUTTON_CLICK_ON);
        registerDefaultState(defaultBlockState().setValue(WALLPAPER, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIT, WALLPAPER);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = super.getStateForPlacement(context);
        if (state == null) {
            return null;
        }
        return state.setValue(WALLPAPER, context.getLevel().getRandom().nextInt(WALLPAPER_COUNT));
    }

    @Override
    protected void toggleLit(BlockState state, Level level, BlockPos pos) {
        if (level.isClientSide) {
            return; // the server decides (random wallpaper) and syncs the new state to everyone
        }
        boolean nowLit = !state.getValue(LIT);
        BlockState next = state.setValue(LIT, nowLit);
        if (nowLit) {
            // pick any wallpaper except the one shown last time
            int current = state.getValue(WALLPAPER);
            int other = (current + 1 + level.random.nextInt(WALLPAPER_COUNT - 1)) % WALLPAPER_COUNT;
            next = next.setValue(WALLPAPER, other);
        }
        level.setBlock(pos, next, 3);
        level.playSound(null, pos, SoundEvents.LEVER_CLICK,
                SoundSource.BLOCKS, 0.6F, nowLit ? 1.2F : 0.9F);
    }
}
