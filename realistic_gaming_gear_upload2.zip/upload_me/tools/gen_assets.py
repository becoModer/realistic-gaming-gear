#!/usr/bin/env python3
"""
Generates every texture, model, blockstate, lang file, loot table and recipe of the
Realistic Gaming Gear mod into src/main/resources.

Usage (from the project root):   python3 tools/gen_assets.py
Requires: Pillow  (pip install pillow)

Re-run it after changing anything here. Block names MUST match ModBlocks.java.
"""
import colorsys
import json
import math
import os
import random
import shutil

from PIL import Image, ImageDraw, ImageFont

MODID = "realisticgaminggear"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", MODID)
DATA = os.path.join(RES, "data", MODID)
TEX_DIR = os.path.join(ASSETS, "textures", "block")

FRAMES = 16  # frames of the animated RGB textures

textures_made = set()


# --------------------------------------------------------------------------- utils
def ensure(path):
    os.makedirs(path, exist_ok=True)


def write_json(path, obj):
    ensure(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write("\n")


def save_tex(name, img, animated=False, frametime=2):
    ensure(TEX_DIR)
    img.save(os.path.join(TEX_DIR, name + ".png"))
    textures_made.add(name)
    if animated:
        write_json(os.path.join(TEX_DIR, name + ".png.mcmeta"),
                   {"animation": {"frametime": frametime, "interpolate": True}})


def hexc(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def clamp(v):
    return max(0, min(255, int(v)))


def shade(c, d):
    return (clamp(c[0] + d), clamp(c[1] + d), clamp(c[2] + d), c[3])


def hue_color(h, v=1.0, s=0.9, a=255):
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, s, v)
    return (int(r * 255), int(g * 255), int(b * 255), a)


def noisy(size, base, amt=5, seed=0):
    rnd = random.Random(seed)
    img = Image.new("RGBA", (size, size), base)
    px = img.load()
    for y in range(size):
        for x in range(size):
            n = rnd.randint(-amt, amt)
            px[x, y] = shade(base, n)
    return img


def rgb_strip_frames(size):
    """Animated rainbow, FRAMES frames stacked vertically."""
    sheet = Image.new("RGBA", (size, size * FRAMES))
    for f in range(FRAMES):
        frame = Image.new("RGBA", (size, size))
        px = frame.load()
        for y in range(size):
            for x in range(size):
                px[x, y] = hue_color((x + y) / (2.0 * size) + f / FRAMES)
        sheet.paste(frame, (0, f * size))
    return sheet


# --------------------------------------------------------------------------- textures
def make_plain_textures():
    # case / plastic colours (16x16 is plenty: they are solid colours)
    plain = {
        "case_black": "#1b1c20", "case_white": "#e4e5e8", "case_gray": "#8a8f98",
        "case_silver": "#b4b9c2", "case_custom": "#3b3550",
        "mouse_gray": "#b7bbc2", "mouse_black": "#202127", "mouse_white": "#ececef",
        "mouse_silver": "#a3a9b3", "wheel_dark": "#2a2b30", "wheel_orange": "#e8791c",
        "wheel_gold": "#d9b23a", "cable_black": "#121214", "rubber": "#161618",
        "dongle": "#2c2f36", "metal_dark": "#34373d",
        "btn_red": "#d83a3a", "btn_green": "#3ec45a", "btn_blue": "#3a6fe0", "btn_yellow": "#e6c32e",
    }
    for i, (name, color) in enumerate(plain.items()):
        save_tex(name, noisy(16, hexc(color), 4, i + 1))

    # translucent case for the transparent keyboard
    save_tex("case_clear", noisy(16, (200, 225, 240, 105), 4, 99))

    # rgb off (dead LEDs)
    save_tex("rgb_off", noisy(16, hexc("#2d2e33"), 3, 7))

    # animated rainbow glow
    save_tex("rgb_anim", rgb_strip_frames(32), animated=True, frametime=2)


def make_honeycomb():
    """Lightweight mouse top: holes (transparent) in a hex-ish grid."""
    size = 64
    img = Image.new("RGBA", (size, size), hexc("#202127"))
    d = ImageDraw.Draw(img)
    r = 3
    pitch = 8
    for row in range(-1, size // 6 + 2):
        for col in range(-1, size // pitch + 2):
            cx = col * pitch + (pitch // 2 if row % 2 else 0)
            cy = row * 6
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(0, 0, 0, 0))
    save_tex("mouse_honey_top", img)


# ---- keyboards -----------------------------------------------------------------
KEY_ROW_WIDTHS = [  # row 0 = front (space bar row, nearest the typist)
    [1.25, 1.25, 1.25, 6.25, 1.25, 1.25, 1.25, 1.25],
    [2.25] + [1] * 10 + [2.75],
    [1.75] + [1] * 11 + [2.25],
    [1.5] + [1] * 12 + [1.5],
    [1] * 13 + [2],
]


def layout_rows(rows):
    """Row width patterns for `rows` rows (row 0 = front)."""
    out = []
    for r in range(rows):
        out.append(KEY_ROW_WIDTHS[r] if r < len(KEY_ROW_WIDTHS) else [1] * 14)
    return out


def keys_frame(size, rows, cap, gap, legend, hue=None, accent=None):
    """One frame of a keycap grid. hue: if not None, gap/legend glow with that hue."""
    img = Image.new("RGBA", (size, size), gap)
    d = ImageDraw.Draw(img)
    patterns = layout_rows(rows)
    for r, widths in enumerate(patterns):
        v1 = round(r * size / rows)
        v2 = round((r + 1) * size / rows)
        total = sum(widths)
        cum = 0.0
        for i, w in enumerate(widths):
            u1 = round(cum / total * size)
            cum += w
            u2 = round(cum / total * size)
            if hue is not None:
                glow = hue_color(hue + (u1 / size) * 0.5)
                d.rectangle((u1, v1, u2 - 1, v2 - 1), fill=glow)
            color = cap
            if accent is not None and (i == 0 and r in (0, rows - 1) or (r == rows - 1 and i == 0)):
                color = accent
            d.rectangle((u1 + 1, v1 + 1, u2 - 2, v2 - 2), fill=color)
            # lit upper-left edge for a bit of keycap depth
            d.line((u1 + 1, v1 + 1, u2 - 2, v1 + 1), fill=shade(color, 22))
            # legend dot
            cx, cy = (u1 + u2) // 2, (v1 + v2) // 2
            if w < 3:
                d.rectangle((cx - 1, cy - 1, cx, cy), fill=legend)
    return img


def make_keyboard_textures():
    size = 128
    specs = {
        # name: (rows, cap, gap, legend)
        "keys_60": (5, hexc("#272830"), hexc("#111216"), hexc("#d8d8dc")),
        "keys_65": (5, hexc("#272830"), hexc("#111216"), hexc("#d8d8dc")),
        "keys_tkl": (6, hexc("#272830"), hexc("#111216"), hexc("#d8d8dc")),
        "keys_full": (6, hexc("#2a2b33"), hexc("#111216"), hexc("#d8d8dc")),
        "keys_black": (6, hexc("#26272d"), hexc("#0f1013"), hexc("#d0d0d4")),
        "keys_white": (6, hexc("#f1f1f3"), hexc("#c3c5cb"), hexc("#555963")),
        "keys_trans": (6, (215, 230, 245, 95), (120, 140, 160, 150), (255, 255, 255, 230)),
    }
    for name, (rows, cap, gap, legend) in specs.items():
        save_tex(name, keys_frame(size, rows, cap, gap, legend))

    # custom board: pastel caps with purple accents (lit = underglow only, unlit same keys)
    save_tex("keys_custom", keys_frame(size, 5, hexc("#e7d9f2"), hexc("#8b7aa8"), hexc("#6c5a88"),
                                      accent=hexc("#9b6bd1")))

    # animated RGB-backlit keyboards
    sheet = Image.new("RGBA", (size, size * FRAMES))
    for f in range(FRAMES):
        frame = keys_frame(size, 6, hexc("#1d1e24"), hexc("#000000"), hexc("#f4f4f7"), hue=f / FRAMES)
        sheet.paste(frame, (0, f * size))
    save_tex("keys_rgb_lit", sheet, animated=True, frametime=3)
    save_tex("keys_rgb_off", keys_frame(size, 6, hexc("#1d1e24"), hexc("#0a0a0c"), hexc("#8e8f95")))


# ---- mousepads ------------------------------------------------------------------
def pad_frame(base, border, hue=None):
    size = 64
    img = noisy(size, base, 3, 11)
    d = ImageDraw.Draw(img)
    for i in range(2):
        col = border if hue is None else hue_color(hue)
        d.rectangle((i, i, size - 1 - i, size - 1 - i), outline=col)
    for k in range(3, size - 3, 4):  # stitching dashes
        col = border if hue is None else hue_color(hue + k / size * 0.6)
        d.line((k, 3, k + 1, 3), fill=col)
        d.line((k, size - 4, k + 1, size - 4), fill=col)
        d.line((3, k, 3, k + 1), fill=col)
        d.line((size - 4, k, size - 4, k + 1), fill=col)
    # little centre mark so the pad doesn't look blank
    d.polygon([(32, 26), (38, 32), (32, 38), (26, 32)], outline=border)
    return img


def make_pad_textures():
    pads = {
        "pad_black": ("#1b1b1f", "#4a4a52"), "pad_white": ("#e9e9ec", "#9a9aa3"),
        "pad_red": ("#b3202a", "#ff8a8a"), "pad_blue": ("#1f4fb3", "#8fb4ff"),
        "pad_purple": ("#6a2fb3", "#c9a2ff"),
    }
    for name, (base, border) in pads.items():
        save_tex(name, pad_frame(hexc(base), hexc(border)))
    save_tex("pad_rgb_off", pad_frame(hexc("#1b1b1f"), hexc("#3a3a40")))
    sheet = Image.new("RGBA", (64, 64 * FRAMES))
    for f in range(FRAMES):
        sheet.paste(pad_frame(hexc("#141417"), hexc("#ffffff"), hue=f / FRAMES), (0, f * 64))
    save_tex("pad_rgb_lit", sheet, animated=True, frametime=3)


# ---- desks ----------------------------------------------------------------------
def wood_texture(base, dark, seed):
    size = 64
    rnd = random.Random(seed)
    img = Image.new("RGBA", (size, size), base)
    d = ImageDraw.Draw(img)
    for y in range(size):
        wave = math.sin(y * 0.35 + rnd.random() * 0.2) * 6
        for x in range(size):
            n = math.sin((x + wave) * 0.28) * 7 + rnd.randint(-4, 4)
            img.putpixel((x, y), shade(base, n))
    for p in range(0, size, 16):  # plank seams
        d.line((0, p, size, p), fill=dark)
    return img


def make_desk_textures():
    save_tex("desk_wood_top", wood_texture(hexc("#a8763e"), hexc("#6f4a24"), 1))
    save_tex("desk_wood_side", wood_texture(hexc("#8e6232"), hexc("#5d3c1b"), 2))
    save_tex("desk_black_top", noisy(64, hexc("#17181c"), 4, 21))
    save_tex("desk_black_side", noisy(64, hexc("#101114"), 3, 22))
    save_tex("desk_white_top", noisy(64, hexc("#e6e7ea"), 3, 23))
    save_tex("desk_white_side", noisy(64, hexc("#c9cbd0"), 3, 24))


def make_v11_textures():
    """Screens (animated wallpaper), cushions, mic mesh, speaker cone, lamp bulb."""
    size = 64

    off = Image.new("RGBA", (size, size), (0, 0, 0, 255))
    d = ImageDraw.Draw(off)
    d.rectangle((3, 3, size - 4, size - 4), fill=hexc("#0b0b10"))
    for k in range(-size, size, 16):  # faint reflection streaks
        d.line((k, size - 4, k + size - 8, 3), fill=hexc("#14141b"), width=3)
    save_tex("screen_off", off)

    save_tex("cushion", noisy(16, hexc("#2b2d33"), 5, 31))

    mesh = Image.new("RGBA", (16, 16), hexc("#3a3c42"))
    d = ImageDraw.Draw(mesh)
    for k in range(0, 16, 3):
        d.line((k, 0, k, 15), fill=hexc("#70737d"))
        d.line((0, k, 15, k), fill=hexc("#70737d"))
    save_tex("mic_mesh", mesh)

    cone = Image.new("RGBA", (64, 64), hexc("#17181c"))
    d = ImageDraw.Draw(cone)
    d.ellipse((4, 4, 59, 59), fill=hexc("#2a2c33"))
    d.ellipse((11, 11, 52, 52), fill=hexc("#101114"))
    d.ellipse((22, 22, 41, 41), fill=hexc("#3b3e47"))
    d.ellipse((28, 28, 35, 35), fill=hexc("#17181c"))
    save_tex("speaker_cone", cone)

    save_tex("lamp_on", noisy(16, hexc("#fff0b0"), 6, 41))
    save_tex("lamp_off", noisy(16, hexc("#cfc7a8"), 4, 42))


# --------------------------------------------------------------------------- models
def tex_ref(name):
    return "%s:block/%s" % (MODID, name)


def box_all(frm, to, tex, shade_faces=True):
    el = {"from": list(frm), "to": list(to),
          "faces": {f: {"texture": "#" + tex} for f in ("down", "up", "north", "south", "west", "east")}}
    if not shade_faces:
        el["shade"] = False
    return el


def box_top(frm, to, top_tex, side_tex, top_uv=None, shade_faces=True):
    faces = {f: {"texture": "#" + side_tex} for f in ("down", "north", "south", "west", "east")}
    faces["up"] = {"texture": "#" + top_tex}
    if top_uv:
        faces["up"]["uv"] = top_uv
    el = {"from": list(frm), "to": list(to), "faces": faces}
    if not shade_faces:
        el["shade"] = False
    return el


def display(scale, cy=1.0):
    """cy = height (in pixels) of the model's visual centre; used to centre it in the GUI slot."""
    ty = round((8 - cy) * 0.866 * scale, 2)
    return {
        "gui": {"rotation": [30, 225, 0], "translation": [0, ty, 0], "scale": [scale] * 3},
        "ground": {"translation": [0, 3, 0], "scale": [0.5] * 3},
        "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 2], "scale": [0.6] * 3},
        "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 4, 0], "scale": [0.6] * 3},
    }


def model_json(textures, elements, scale, render_type="minecraft:cutout", cy=1.0):
    textures = dict(textures)
    textures.setdefault("particle", next(iter(textures.values())))
    return {
        "render_type": render_type,
        "textures": {k: tex_ref(v) for k, v in textures.items()},
        "elements": elements,
        "display": display(scale, cy),
    }


# ---- mouse ----------------------------------------------------------------------
def mouse_elements(body, top, wheel, hump=2.2, cable=True, dongle=False, rgb=None, side_btn=False):
    els = []
    if rgb:  # underglow ring, slightly wider than the body
        els.append(box_all((5.8, 0, 5.2), (10.2, 0.4, 10.8), rgb, shade_faces=False))
    els.append(box_all((6, 0.4, 5), (10, 1.2, 11), body))
    els.append(box_top((6.2, 1.2, 5.2), (9.8, hump, 8.4), top, body))      # palm hump (rear)
    els.append(box_top((6.2, 1.2, 8.4), (7.7, 1.7, 10.8), top, body))      # left button
    els.append(box_top((8.3, 1.2, 8.4), (9.8, 1.7, 10.8), top, body))      # right button
    els.append(box_all((7.75, 1.2, 8.6), (8.25, 2.0, 9.7), wheel))          # scroll wheel
    if side_btn:
        els.append(box_all((6.0, 0.7, 6.4), (6.2, 1.3, 8.0), wheel))
    if cable:
        els.append(box_all((7.6, 0.3, 11), (8.4, 0.7, 16), "cable_black"))
    if dongle:
        els.append(box_all((11, 0, 7), (12.6, 0.7, 8.8), "dongle"))
        els.append(box_all((12.6, 0.2, 7.4), (13.2, 0.5, 8.4), "metal_dark"))
    return els


MICE = {
    # name: (body, top, wheel, hump, cable, dongle, rgb?, side buttons)
    "mouse_basic": ("mouse_gray", "mouse_gray", "wheel_dark", 2.0, True, False, False, False),
    "mouse_rgb": ("mouse_black", "mouse_black", "wheel_dark", 2.1, True, False, True, False),
    "mouse_lightweight": ("mouse_black", "mouse_honey_top", "wheel_orange", 2.0, True, False, False, True),
    "mouse_pro": ("mouse_white", "mouse_white", "wheel_orange", 2.3, True, False, False, True),
    "mouse_wireless": ("mouse_gray", "mouse_black", "wheel_dark", 2.1, False, True, False, True),
    "mouse_ultra": ("mouse_silver", "mouse_silver", "wheel_gold", 2.4, True, False, True, True),
}


def gen_mouse_models():
    out = {}
    for name, (body, top, wheel, hump, cable, dongle, rgb, side) in MICE.items():
        textures = {body: body, top: top, wheel: wheel, "cable_black": "cable_black",
                    "dongle": "dongle", "metal_dark": "metal_dark"}
        if rgb:
            for lit in (False, True):
                tx = dict(textures)
                tx["rgb"] = "rgb_anim" if lit else "rgb_off"
                els = mouse_elements(body, top, wheel, hump, cable, dongle, "rgb", side)
                out[name + ("_lit" if lit else "")] = model_json(tx, els, 1.6)
        else:
            els = mouse_elements(body, top, wheel, hump, cable, dongle, None, side)
            out[name] = model_json(textures, els, 1.6)
    return out


# ---- keyboards ------------------------------------------------------------------
KEYBOARDS = {
    # name: (box x1,z1,x2,z2, case tex, keys tex (unlit), keys tex (lit) or None, underglow, render type)
    "keyboard_60": ((2, 5, 14, 11), "case_black", "keys_60", None, False, "minecraft:cutout"),
    "keyboard_65": ((1.5, 5, 14.5, 11), "case_black", "keys_65", None, False, "minecraft:cutout"),
    "keyboard_tkl": ((0.5, 4.5, 15.5, 11.5), "case_black", "keys_tkl", None, False, "minecraft:cutout"),
    "keyboard_full": ((0, 4, 16, 12), "case_black", "keys_full", None, False, "minecraft:cutout"),
    "keyboard_custom": ((1, 5, 15, 11), "case_custom", "keys_custom", None, True, "minecraft:cutout"),
    "keyboard_rgb": ((0, 4, 16, 12), "case_black", "keys_rgb_off", "keys_rgb_lit", True, "minecraft:cutout"),
    "keyboard_white": ((0.5, 4.5, 15.5, 11.5), "case_white", "keys_white", None, False, "minecraft:cutout"),
    "keyboard_black": ((0.5, 4.5, 15.5, 11.5), "case_black", "keys_black", None, False, "minecraft:cutout"),
    "keyboard_transparent": ((0.5, 4.5, 15.5, 11.5), "case_clear", "keys_trans", None, False,
                             "minecraft:translucent"),
}


def keyboard_elements(box, case, keys, underglow, rgb_tex, cable_tex="cable_black"):
    x1, z1, x2, z2 = box
    els = []
    base_y = 1.0
    case_bottom = 0.0
    if underglow:
        els.append(box_all((x1, 0, z1), (x2, 0.35, z2), rgb_tex, shade_faces=False))
        case_bottom = 0.35
        base_y = 1.0 if case != "case_custom" else 1.4
        els.append(box_all((x1 + 0.2, case_bottom, z1 + 0.2), (x2 - 0.2, base_y, z2 - 0.2), case))
    else:
        els.append(box_all((x1, 0, z1), (x2, base_y, z2), case))
    # keycap plate, 3 stair-stepped slices (front low, back high) like a real board
    px1, pz1, px2, pz2 = x1 + 0.5, z1 + 0.5, x2 - 0.5, z2 - 0.5
    depth = pz2 - pz1
    heights = [base_y + 0.2, base_y + 0.4, base_y + 0.6]
    for i in range(3):
        za = pz1 + depth * i / 3.0
        zb = pz1 + depth * (i + 1) / 3.0
        uv = [0, round(16 * (za - pz1) / depth, 3), 16, round(16 * (zb - pz1) / depth, 3)]
        els.append(box_top((px1, base_y, za), (px2, heights[i], zb), "keys", "case", top_uv=uv))
    els.append(box_all((7.6, 0.25, z2), (8.4, 0.65, 16), cable_tex))
    return els


def gen_keyboard_models():
    out = {}
    for name, (box, case, keys, keys_lit, underglow, render) in KEYBOARDS.items():
        rgb_capable = name in ("keyboard_custom", "keyboard_rgb")
        variants = [(False, keys)] if not rgb_capable else [(False, keys), (True, keys_lit or keys)]
        for lit, ktex in variants:
            tx = {"case": case, "keys": ktex, "cable_black": "cable_black"}
            rgb_tex = None
            if underglow:
                tx["rgb"] = "rgb_anim" if lit else "rgb_off"
                rgb_tex = "rgb"
            els = keyboard_elements(box, "case", "keys", underglow, rgb_tex)
            # keyboard_elements refers to case by name "case"; custom needs its own base height
            if name == "keyboard_custom":
                els = keyboard_elements(box, "case_custom", "keys", underglow, rgb_tex)
                tx["case_custom"] = "case_custom"
                # side/front faces of key slices use "case": point it at the custom case colour
                tx["case"] = "case_custom"
            out[name + ("_lit" if lit else "")] = model_json(tx, els, 0.85, render)
    return out


# ---- mousepads ------------------------------------------------------------------
PADS = {
    "mousepad_black": ("pad_black", False), "mousepad_white": ("pad_white", False),
    "mousepad_red": ("pad_red", False), "mousepad_blue": ("pad_blue", False),
    "mousepad_purple": ("pad_purple", False), "mousepad_rgb": ("pad_rgb_off", True),
}


def gen_pad_models():
    out = {}
    for name, (tex, rgb) in PADS.items():
        for lit in ((False, True) if rgb else (False,)):
            top_tex = "pad_rgb_lit" if lit else tex
            els = [box_all((1, 0, 2), (15, 0.4, 14), "rubber"),
                   box_top((1, 0.4, 2), (15, 1, 14), "top", "rubber", top_uv=[0, 0, 16, 16])]
            # use cloth colour on the sides too, so the edge doesn't look striped
            els[1]["faces"]["north"] = els[1]["faces"]["south"] = {"texture": "#edge"}
            els[1]["faces"]["west"] = els[1]["faces"]["east"] = {"texture": "#edge"}
            edge = "rubber" if rgb else tex
            out[name + ("_lit" if lit else "")] = model_json(
                {"top": top_tex, "rubber": "rubber", "edge": edge}, els, 0.75)
    return out


# ---- desks ----------------------------------------------------------------------
DESKS = {
    "desk_wooden": ("desk_wood_top", "desk_wood_side", "desk_wood_side", False),
    "desk_black": ("desk_black_top", "desk_black_side", "metal_dark", False),
    "desk_white": ("desk_white_top", "desk_white_side", "metal_dark", False),
    "desk_rgb": ("desk_black_top", "desk_black_side", "metal_dark", True),
}


def gen_desk_models():
    out = {}
    legs = [(0.5, 0.5), (13.5, 0.5), (0.5, 13.5), (13.5, 13.5)]
    for name, (top, side, leg, rgb) in DESKS.items():
        for lit in ((False, True) if rgb else (False,)):
            els = [box_top((0, 13, 0), (16, 16, 16), "top", "side", top_uv=[0, 0, 16, 16])]
            for (lx, lz) in legs:
                els.append(box_all((lx, 0, lz), (lx + 2, 13, lz + 2), "leg"))
            tx = {"top": top, "side": side, "leg": leg}
            if rgb:
                tx["rgb"] = "rgb_anim" if lit else "rgb_off"
                # light strip tucked under the desk top, visible from the sides and below
                els.append(box_all((0.2, 12.2, 0.2), (15.8, 13, 15.8), "rgb", shade_faces=False))
            out[name + ("_lit" if lit else "")] = model_json(tx, els, 0.625, "minecraft:solid")
    return out


# ---- V1.1.1: monitor wallpapers + Windows-11-style desktop -----------------------
# Raw wallpaper strips (192x112 frames stacked vertically) live in tools/wallpapers/.
# This script lays a generic Windows 11 style desktop (centred taskbar, a few apps, an
# Explorer-like window, desktop icons) over every frame. All icons are generic drawings.
WALLPAPER_COUNT = 4
WP_W, WP_H = 192, 112
WALLPAPER_DIR = os.path.join(ROOT, "tools", "wallpapers")
SHOW_WINDOW = False  # True = draw an Explorer-like window over the wallpaper


def _font(size):
    from PIL import ImageFont
    try:
        return ImageFont.load_default(size=size)
    except TypeError:  # old Pillow
        return ImageFont.load_default()


def win11_overlay():
    w, h = WP_W, WP_H
    ov = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    white = (245, 247, 252, 255)
    accent = (110, 190, 255, 255)

    # --- Explorer-like window (acrylic light). Off by default: it hides the wallpaper. ---
    wd = ImageDraw.Draw(ov if SHOW_WINDOW else Image.new("RGBA", (w, h)))
    wx1, wy1, wx2, wy2 = 62, 14, 152, 82
    wd.rounded_rectangle((wx1, wy1, wx2, wy2), radius=3, fill=(238, 241, 249, 208))
    wd.rounded_rectangle((wx1, wy1, wx2, wy1 + 8), radius=3, fill=(250, 251, 255, 232))
    wd.rectangle((wx1, wy1 + 5, wx2, wy1 + 8), fill=(250, 251, 255, 232))
    wd.ellipse((wx1 + 3, wy1 + 2, wx1 + 6, wy1 + 5), fill=(250, 200, 70, 255))       # tiny title icon
    wd.rectangle((wx1 + 9, wy1 + 3, wx1 + 34, wy1 + 4), fill=(110, 115, 130, 255))   # title text
    for i in range(3):                                                              # window controls
        cx = wx2 - 14 + i * 4
        wd.rectangle((cx, wy1 + 3, cx + 2, wy1 + 4), fill=(90, 95, 110, 255))
    wd.rectangle((wx1 + 1, wy1 + 9, wx1 + 24, wy2 - 1), fill=(226, 230, 241, 235))    # sidebar
    for i in range(5):
        y = wy1 + 12 + i * 8
        if i == 1:
            wd.rounded_rectangle((wx1 + 3, y - 1, wx1 + 22, y + 4), radius=1, fill=(200, 222, 252, 255))
        wd.rectangle((wx1 + 5, y + 1, wx1 + 6, y + 2), fill=(70, 130, 220, 255))
        wd.rectangle((wx1 + 9, y + 1, wx1 + 9 + 8 + (i % 3) * 3, y + 2), fill=(120, 125, 140, 255))
    wd.rounded_rectangle((wx1 + 27, wy1 + 10, wx2 - 4, wy1 + 15), radius=2, fill=(255, 255, 255, 255))  # address bar
    for r in range(3):                                                               # file grid
        for c in range(4):
            fx = wx1 + 30 + c * 14
            fy = wy1 + 20 + r * 17
            wd.rectangle((fx, fy + 2, fx + 8, fy + 8), fill=(250, 200, 70, 255))
            wd.rectangle((fx, fy, fx + 4, fy + 2), fill=(250, 200, 70, 255))
            wd.rectangle((fx, fy + 11, fx + 8, fy + 12), fill=(110, 115, 130, 255))

    # --- desktop icons (top left) ---
    for i, kind in enumerate(("pc", "bin", "folder", "browser", "media")):
        ix, iy = 8, 8 + i * 17
        if kind == "pc":
            d.rectangle((ix, iy, ix + 9, iy + 6), fill=(90, 160, 235, 255), outline=white)
            d.rectangle((ix + 3, iy + 7, ix + 6, iy + 8), fill=white)
        elif kind == "bin":
            d.polygon([(ix + 1, iy + 2), (ix + 8, iy + 2), (ix + 7, iy + 9), (ix + 2, iy + 9)],
                      fill=(190, 198, 212, 255))
            d.rectangle((ix, iy + 1, ix + 9, iy + 2), fill=white)
        elif kind == "folder":
            d.rectangle((ix, iy + 2, ix + 9, iy + 8), fill=(250, 200, 70, 255))
            d.rectangle((ix, iy, ix + 4, iy + 2), fill=(250, 200, 70, 255))
        elif kind == "browser":
            d.ellipse((ix, iy, ix + 9, iy + 9), fill=(60, 130, 230, 255))
            d.arc((ix + 2, iy + 2, ix + 7, iy + 7), 0, 270, fill=white)
        else:
            d.rounded_rectangle((ix, iy, ix + 9, iy + 9), radius=2, fill=(140, 90, 220, 255))
            d.polygon([(ix + 3, iy + 2), (ix + 3, iy + 7), (ix + 7, iy + 4)], fill=white)
        d.rectangle((ix, iy + 11, ix + 9, iy + 11), fill=(255, 255, 255, 230))     # label

    # --- taskbar ---
    ty = h - 10
    d.rectangle((0, ty, w, h), fill=(22, 24, 33, 222))
    d.line((0, ty, w, ty), fill=(255, 255, 255, 40))
    x = 61
    d.ellipse((x, ty + 2, x + 6, ty + 8), outline=accent)                           # start button
    d.ellipse((x + 2, ty + 4, x + 4, ty + 6), fill=accent)
    x += 9
    d.rounded_rectangle((x, ty + 2, x + 22, ty + 8), radius=3, fill=(232, 235, 244, 240))  # search
    d.ellipse((x + 2, ty + 3, x + 5, ty + 6), outline=(110, 115, 130, 255))
    d.rectangle((x + 8, ty + 4, x + 17, ty + 5), fill=(170, 175, 190, 255))
    x += 25
    d.rectangle((x, ty + 2, x + 4, ty + 6), outline=white)                          # task view
    d.rectangle((x + 2, ty + 4, x + 6, ty + 8), outline=white)
    x += 9
    d.rectangle((x, ty + 4, x + 6, ty + 8), fill=(250, 200, 70, 255))               # files
    d.rectangle((x, ty + 3, x + 3, ty + 4), fill=(250, 200, 70, 255))
    d.rectangle((x + 1, ty + 9, x + 5, ty + 9), fill=accent)
    x += 9
    d.ellipse((x, ty + 2, x + 6, ty + 8), fill=(60, 130, 230, 255))                 # browser
    d.arc((x + 1, ty + 3, x + 5, ty + 7), 0, 270, fill=white)
    x += 9
    d.rounded_rectangle((x, ty + 2, x + 6, ty + 8), radius=1, fill=(140, 90, 220, 255))  # media
    d.polygon([(x + 2, ty + 3), (x + 2, ty + 7), (x + 5, ty + 5)], fill=white)
    x += 9
    d.ellipse((x, ty + 2, x + 6, ty + 8), fill=(170, 176, 192, 255))                # settings
    d.ellipse((x + 2, ty + 4, x + 4, ty + 6), fill=(22, 24, 33, 255))

    # --- tray: wifi, battery, clock ---
    wx = 150
    for r in (2, 4, 6):
        d.arc((wx - r, ty + 8 - r, wx + r, ty + 8 + r), 225, 315, fill=white)
    d.rectangle((wx + 9, ty + 3, wx + 17, ty + 7), outline=white)
    d.rectangle((wx + 10, ty + 4, wx + 15, ty + 6), fill=(120, 230, 150, 255))
    d.rectangle((wx + 18, ty + 4, wx + 18, ty + 6), fill=white)
    d.text((wx + 23, ty + 1), "11:26", fill=white, font=_font(7))
    return ov


def make_wallpaper_textures():
    ensure(TEX_DIR)
    # Preferred: ready-made sheets (full-length videos + desktop UI) made by tools/make_wallpapers.py
    ready = [os.path.join(ROOT, "tools", "video_textures", "wallpaper_%d.png" % i)
             for i in range(WALLPAPER_COUNT)]
    if all(os.path.exists(p) and os.path.exists(p + ".mcmeta") for p in ready):
        for n, src in enumerate(ready, start=1):
            name = "screen_wp%d" % n
            shutil.copy(src, os.path.join(TEX_DIR, name + ".png"))
            shutil.copy(src + ".mcmeta", os.path.join(TEX_DIR, name + ".png.mcmeta"))
            textures_made.add(name)
        return
    overlay = win11_overlay()
    for n in range(1, WALLPAPER_COUNT + 1):
        raw = os.path.join(WALLPAPER_DIR, "wallpaper_%d.png" % n)
        if os.path.exists(raw):
            strip = Image.open(raw).convert("RGBA")
            frames = strip.size[1] // WP_H
            out = Image.new("RGBA", strip.size)
            for f in range(frames):
                frame = strip.crop((0, f * WP_H, WP_W, (f + 1) * WP_H))
                out.paste(Image.alpha_composite(frame, overlay), (0, f * WP_H))
        else:  # fallback if the wallpaper strips are missing: animated gradient
            frames = FRAMES
            out = Image.new("RGBA", (WP_W, WP_H * frames))
            for f in range(frames):
                frame = Image.new("RGBA", (WP_W, WP_H))
                px = frame.load()
                for y in range(WP_H):
                    for x in range(WP_W):
                        px[x, y] = hue_color(0.5 + 0.1 * n + (x + y) / 600.0 + f / (frames * 4.0), 0.55, 0.8)
                out.paste(Image.alpha_composite(frame, overlay), (0, f * WP_H))
        name = "screen_wp%d" % n
        out.save(os.path.join(TEX_DIR, name + ".png"))
        textures_made.add(name)
        write_json(os.path.join(TEX_DIR, name + ".png.mcmeta"),
                   {"animation": {"frametime": 2, "width": WP_W, "height": WP_H}})


def monitor_blockstate(name):
    variants = {}
    for facing, y in ROT.items():
        for lit in (False, True):
            for w in range(WALLPAPER_COUNT):
                model = "%s_wp%d" % (name, w + 1) if lit else name
                entry = {"model": "%s:block/%s" % (MODID, model)}
                if y:
                    entry["y"] = y
                variants["facing=%s,lit=%s,wallpaper=%d" % (facing, str(lit).lower(), w)] = entry
    return {"variants": variants}


# ---- V1.1: mouse on a mousepad -------------------------------------------------
def shift_elements(els, dx, dy, dz):
    out = []
    for el in els:
        e = dict(el)
        e["from"] = [round(el["from"][0] + dx, 3), round(el["from"][1] + dy, 3), round(el["from"][2] + dz, 3)]
        e["to"] = [round(el["to"][0] + dx, 3), round(el["to"][1] + dy, 3), round(el["to"][2] + dz, 3)]
        out.append(e)
    return out


def gen_mouse_onpad_models():
    """Mouse models used as a part of the mousepad blockstate (sitting on the 1px thick pad)."""
    out = {}
    for name, (body, top, wheel, hump, cable, dongle, rgb, side) in MICE.items():
        base_tx = {body: body, top: top, wheel: wheel, "cable_black": "cable_black",
                   "dongle": "dongle", "metal_dark": "metal_dark"}
        for lit in ((False, True) if rgb else (False,)):
            tx = dict(base_tx)
            if rgb:
                tx["rgb"] = "rgb_anim" if lit else "rgb_off"
            els = mouse_elements(body, top, wheel, hump, cable, dongle, "rgb" if rgb else None, side)
            els = shift_elements(els, 2.5, 1.0, 0)  # +x: right side of the pad, +y: on top of it
            out[name + "_onpad" + ("_lit" if lit else "")] = model_json(tx, els, 1.6)
    return out


MOUSE_TYPES = ["basic", "rgb", "lightweight", "pro", "wireless", "ultra"]
MOUSE_RGB_TYPES = {"rgb", "ultra"}


def pad_blockstate(name, pad_rgb):
    """Multipart blockstate: the pad itself plus (optionally) the mouse that is on it."""
    parts = []

    def apply(model, y):
        a = {"model": "%s:block/%s" % (MODID, model)}
        if y:
            a["y"] = y
        return a

    for facing, y in ROT.items():
        if pad_rgb:
            for lit in (False, True):
                parts.append({"when": {"AND": [{"facing": facing}, {"lit": str(lit).lower()}]},
                              "apply": apply(name + ("_lit" if lit else ""), y)})
        else:
            parts.append({"when": {"facing": facing}, "apply": apply(name, y)})
        for m in MOUSE_TYPES:
            if m in MOUSE_RGB_TYPES:
                for lit in (False, True):
                    parts.append({"when": {"AND": [{"facing": facing}, {"mouse": m},
                                                   {"lit": str(lit).lower()}]},
                                  "apply": apply("mouse_%s_onpad%s" % (m, "_lit" if lit else ""), y)})
            else:
                parts.append({"when": {"AND": [{"facing": facing}, {"mouse": m}]},
                              "apply": apply("mouse_%s_onpad" % m, y)})
    return {"multipart": parts}


def pad_loot(name):
    """Mousepad drops itself, plus the mouse that is on it."""
    pools = [loot_table(name)["pools"][0]]
    entries = []
    for m in MOUSE_TYPES:
        entries.append({
            "type": "minecraft:item",
            "name": "%s:mouse_%s" % (MODID, m),
            "conditions": [{"condition": "minecraft:block_state_property",
                            "block": "%s:%s" % (MODID, name),
                            "properties": {"mouse": m}}],
        })
    pools.append({"rolls": 1, "entries": entries,
                  "conditions": [{"condition": "minecraft:survives_explosion"}]})
    return {"type": "minecraft:block", "pools": pools}


# ---- V1.1: monitors -------------------------------------------------------------
MONITORS = {
    # name: (x1, x2, panel y1, panel y2, curve segments)
    "monitor_24": (3, 13, 2.5, 8.5, 1),
    "monitor_27": (2, 14, 3, 10, 1),
    "monitor_32": (1, 15, 3, 11.5, 1),
    "monitor_curved": (0.5, 15.5, 3, 10, 5),
    "monitor_ultrawide": (0, 16, 3, 10.5, 1),
}


def monitor_elements(x1, x2, y1, y2, segs):
    els = []
    cx = (x1 + x2) / 2.0
    els.append(box_all((cx - 3.5, 0, 6), (cx + 3.5, 0.6, 10), "case_black"))              # base
    els.append(box_all((cx - 0.7, 0.6, 8.2), (cx + 0.7, y1 + 0.2, 8.8), "case_black"))   # neck
    w = (x2 - x1) / float(segs)
    z_offsets = [0.0] if segs == 1 else [-0.8, -0.35, 0.0, -0.35, -0.8]
    for i in range(segs):
        xa = x1 + i * w
        zo = z_offsets[i]
        el = box_all((round(xa, 3), y1, 8.0 + zo), (round(xa + w, 3), y2, 8.8 + zo), "case_black",
                     shade_faces=False)
        el["faces"]["north"] = {"texture": "#screen",
                                "uv": [round(16.0 * i / segs, 3), 0, round(16.0 * (i + 1) / segs, 3), 16]}
        els.append(el)
    return els


def gen_monitor_models():
    out = {}
    for name, (x1, x2, y1, y2, segs) in MONITORS.items():
        els = monitor_elements(x1, x2, y1, y2, segs)
        # screen off
        out[name] = model_json({"case_black": "case_black", "screen": "screen_off"}, els, 0.9, cy=y2 / 2.0)
        # screen on: one model per wallpaper (screen_wp1 .. screen_wp4)
        for n in range(1, WALLPAPER_COUNT + 1):
            tx = {"case_black": "case_black", "screen": "screen_wp%d" % n}
            out["%s_wp%d" % (name, n)] = model_json(tx, els, 0.9, cy=y2 / 2.0)
    return out


# ---- V1.1: accessories ----------------------------------------------------------
def acc_headset(lit):
    tx = {"body": "case_black", "cushion": "cushion", "accent": "wheel_orange"}
    els = [
        box_all((3, 0, 6), (5, 3.2, 10), "body"), box_all((11, 0, 6), (13, 3.2, 10), "body"),
        box_all((3.5, 3.2, 7), (12.5, 4.2, 9), "body"),                                    # headband
        box_all((5, 0.4, 6.3), (5.6, 2.8, 9.7), "cushion"), box_all((10.4, 0.4, 6.3), (11, 2.8, 9.7), "cushion"),
        box_all((2.9, 0.6, 6.6), (3.0, 2.6, 9.4), "accent"), box_all((13.0, 0.6, 6.6), (13.1, 2.6, 9.4), "accent"),
        box_all((3, 0.5, 10), (3.4, 1, 12.5), "body"), box_all((2.9, 0.4, 12.5), (3.5, 1.1, 13.3), "body"),  # mic boom
    ]
    return tx, els, 1.5, 2.0


def acc_headset_stand(lit):
    tx = {"body": "case_black", "cushion": "cushion", "metal": "case_silver",
          "rgb": "rgb_anim" if lit else "rgb_off"}
    els = [
        box_all((5.3, 0, 5.3), (10.7, 0.4, 10.7), "rgb", shade_faces=False),
        box_all((5.5, 0.4, 5.5), (10.5, 1.0, 10.5), "body"),
        box_all((7.4, 1.0, 7.4), (8.6, 10.5, 8.6), "metal"),
        box_all((6, 10.5, 7), (10, 11.3, 9), "metal"),
        box_all((4.5, 11.3, 7), (11.5, 12.2, 9), "body"),                                  # headband on the hook
        box_all((4.5, 6, 7), (5.5, 11.3, 9), "body"), box_all((10.5, 6, 7), (11.5, 11.3, 9), "body"),
        box_all((3.6, 3.8, 6.3), (5.5, 8.4, 9.7), "body"), box_all((10.5, 3.8, 6.3), (12.4, 8.4, 9.7), "body"),
        box_all((5.5, 4.2, 6.7), (6.0, 8.0, 9.3), "cushion"), box_all((10.0, 4.2, 6.7), (10.5, 8.0, 9.3), "cushion"),
    ]
    return tx, els, 0.9, 6.0


def acc_microphone(lit):
    tx = {"body": "case_black", "metal": "case_silver", "mesh": "mic_mesh",
          "rgb": "rgb_anim" if lit else "rgb_off"}
    els = [
        box_all((6, 0, 6), (10, 0.3, 10), "rgb", shade_faces=False),
        box_all((6.2, 0.3, 6.2), (9.8, 1.0, 9.8), "body"),
        box_all((7.6, 1.0, 7.6), (8.4, 5.6, 8.4), "metal"),
        box_all((6.6, 5.6, 6.6), (9.4, 6.2, 9.4), "metal"),
        box_all((6.8, 6.2, 6.8), (9.2, 10.5, 9.2), "mesh"),
        box_all((7.2, 10.5, 7.2), (8.8, 10.9, 8.8), "metal"),
    ]
    return tx, els, 1.0, 5.0


def acc_speaker(lit):
    tx = {"body": "case_black", "cone": "speaker_cone", "rgb": "rgb_anim" if lit else "rgb_off"}
    els = [
        box_all((5, 0, 5), (11, 11, 11), "body"),
        box_all((5.6, 1.2, 4.9), (10.4, 6.0, 5.0), "cone"),     # woofer (front = north)
        box_all((6.8, 7.5, 4.9), (9.2, 9.9, 5.0), "cone"),      # tweeter
        box_all((5.3, 11, 5.3), (10.7, 11.3, 10.7), "rgb", shade_faces=False),
    ]
    return tx, els, 1.0, 5.5


def acc_desk_lamp(lit):
    tx = {"body": "case_black", "metal": "case_silver", "bulb": "lamp_on" if lit else "lamp_off"}
    els = [
        box_all((6, 0, 6), (10, 0.8, 10), "body"),
        box_all((7.6, 0.8, 7.6), (8.4, 8.5, 8.4), "metal"),
        box_all((5.5, 8.5, 5.5), (10.5, 11, 10.5), "body"),
        box_all((6, 8.2, 6), (10, 8.5, 10), "bulb", shade_faces=not lit),
    ]
    return tx, els, 0.9, 5.5


def acc_controller(lit):
    tx = {"body": "case_black", "stick": "case_gray", "red": "btn_red", "green": "btn_green",
          "blue": "btn_blue", "yellow": "btn_yellow"}
    els = [
        box_all((5, 0.2, 5.5), (11, 1.5, 9), "body"),
        box_all((4.5, 0, 6.5), (6, 1.2, 9.8), "body"), box_all((10, 0, 6.5), (11.5, 1.2, 9.8), "body"),
        box_all((6.2, 1.5, 7.6), (7.4, 2.1, 8.8), "stick"), box_all((8.4, 1.5, 6.2), (9.6, 2.1, 7.4), "stick"),
        box_all((9.9, 1.5, 6.3), (10.5, 1.8, 6.9), "yellow"), box_all((9.9, 1.5, 7.9), (10.5, 1.8, 8.5), "green"),
        box_all((9.3, 1.5, 7.1), (9.9, 1.8, 7.7), "blue"), box_all((10.5, 1.5, 7.1), (11.0, 1.8, 7.7), "red"),
    ]
    return tx, els, 1.8, 1.0


ACCESSORIES = {
    "headset": (acc_headset, False), "headset_stand": (acc_headset_stand, True),
    "microphone": (acc_microphone, True), "speaker": (acc_speaker, True),
    "desk_lamp": (acc_desk_lamp, True), "controller": (acc_controller, False),
}


def gen_accessory_models():
    out = {}
    for name, (fn, rgb) in ACCESSORIES.items():
        for lit in ((False, True) if rgb else (False,)):
            tx, els, scale, cy = fn(lit)
            out[name + ("_lit" if lit else "")] = model_json(tx, els, scale, cy=cy)
    return out


# --------------------------------------------------------------------------- blockstates etc.
ROT = {"north": 0, "east": 90, "south": 180, "west": 270}


def blockstate(name, rgb, has_facing):
    variants = {}
    facings = ROT.items() if has_facing else [(None, 0)]
    for facing, y in facings:
        for lit in (False, True):
            key = []
            if facing:
                key.append("facing=" + facing)
            key.append("lit=" + ("true" if lit else "false"))
            model = name + ("_lit" if (lit and rgb) else "")
            entry = {"model": "%s:block/%s" % (MODID, model)}
            if y:
                entry["y"] = y
            variants[",".join(key)] = entry
    return {"variants": variants}


NICE = {
    "mouse_basic": "Basic Mouse", "mouse_rgb": "RGB Mouse", "mouse_lightweight": "Lightweight Mouse",
    "mouse_pro": "Pro Mouse", "mouse_wireless": "Wireless Mouse", "mouse_ultra": "Ultra Mouse",
    "keyboard_60": "60% Keyboard", "keyboard_65": "65% Keyboard", "keyboard_tkl": "TKL Keyboard",
    "keyboard_full": "Full-size Keyboard", "keyboard_custom": "Custom Keyboard",
    "keyboard_rgb": "RGB Mechanical Keyboard", "keyboard_white": "White Keyboard",
    "keyboard_black": "Black Keyboard", "keyboard_transparent": "Transparent Keyboard",
    "mousepad_black": "Black Mousepad", "mousepad_white": "White Mousepad",
    "mousepad_red": "Red Mousepad", "mousepad_blue": "Blue Mousepad",
    "mousepad_purple": "Purple Mousepad", "mousepad_rgb": "RGB Mousepad",
    "desk_wooden": "Wooden Desk", "desk_black": "Black Gaming Desk",
    "desk_white": "White Gaming Desk", "desk_rgb": "RGB Gaming Desk",
    "monitor_24": "24-inch Monitor", "monitor_27": "27-inch Monitor", "monitor_32": "32-inch Monitor",
    "monitor_curved": "Curved Monitor", "monitor_ultrawide": "Ultrawide Monitor",
    "headset": "Gaming Headset", "headset_stand": "RGB Headset Stand", "microphone": "RGB Microphone",
    "speaker": "RGB Desktop Speaker", "desk_lamp": "Desk Lamp", "controller": "Game Controller",
    "pc_mini_starter": "Starter Mini PC", "pc_budget_gamer": "Budget Gamer PC", "pc_stealth": "Stealth PC",
    "pc_white_gaming": "White Gaming PC", "pc_wood": "Wood Edition PC", "pc_snow": "Snow Build PC",
    "pc_neon": "Neon Build PC", "pc_panoramic": "Panoramic PC", "pc_high_end": "High-End PC",
    "pc_red_beast": "Red Beast PC", "pc_fish_tank": "Fish Tank PC", "pc_vertical": "Vertical Tower PC",
    "pc_mini_beast": "Mini Beast PC",
    "plaque_silver": "Silver Creator Plaque (100K)", "plaque_gold": "Gold Creator Plaque (1M)",
    "plaque_diamond": "Diamond Creator Plaque (10M)", "coffee_mug": "Coffee Mug",
    "energy_can": "Energy Can", "desk_plant": "Desk Cactus", "rubber_duck": "Rubber Duck",
}

ALL_NAMES = list(NICE.keys())
RGB_NAMES = {"mouse_rgb", "mouse_ultra", "keyboard_custom", "keyboard_rgb", "mousepad_rgb", "desk_rgb",
             "monitor_24", "monitor_27", "monitor_32", "monitor_curved", "monitor_ultrawide",
             "headset_stand", "microphone", "speaker", "desk_lamp"}


def loot_table(name):
    return {
        "type": "minecraft:block",
        "pools": [{
            "rolls": 1,
            "entries": [{"type": "minecraft:item", "name": "%s:%s" % (MODID, name)}],
            "conditions": [{"condition": "minecraft:survives_explosion"}],
        }],
    }


def mod(name):
    return {"item": "%s:%s" % (MODID, name)}


def van(name):
    return {"item": "minecraft:" + name}


def shaped(result, pattern, key):
    return {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern, "key": key,
            "result": {"item": "%s:%s" % (MODID, result), "count": 1}}


def shapeless(result, ingredients):
    return {"type": "minecraft:crafting_shapeless", "category": "misc", "ingredients": ingredients,
            "result": {"item": "%s:%s" % (MODID, result), "count": 1}}


def recipes():
    glow = [van("redstone"), van("glowstone_dust")]
    r = {
        "mouse_basic": shaped("mouse_basic", ["BB", "II"],
                              {"B": van("stone_button"), "I": van("iron_nugget")}),
        "mouse_rgb": shapeless("mouse_rgb", [mod("mouse_basic")] + glow),
        "mouse_lightweight": shapeless("mouse_lightweight",
                                       [mod("mouse_basic"), van("feather"), van("iron_nugget")]),
        "mouse_pro": shapeless("mouse_pro", [mod("mouse_basic"), van("iron_ingot"), van("redstone")]),
        "mouse_wireless": shapeless("mouse_wireless",
                                    [mod("mouse_basic"), van("ender_pearl"), van("redstone")]),
        "mouse_ultra": shapeless("mouse_ultra", [mod("mouse_pro"), van("diamond"), van("glowstone_dust")]),
        "keyboard_60": shaped("keyboard_60", ["BBB", "III"],
                              {"B": van("stone_button"), "I": van("iron_ingot")}),
        "keyboard_65": shapeless("keyboard_65", [mod("keyboard_60"), van("stone_button")]),
        "keyboard_tkl": shapeless("keyboard_tkl", [mod("keyboard_65"), van("stone_button")]),
        "keyboard_full": shapeless("keyboard_full", [mod("keyboard_tkl"), van("stone_button")]),
        "keyboard_custom": shapeless("keyboard_custom",
                                     [mod("keyboard_60"), van("amethyst_shard"), van("iron_ingot")]),
        "keyboard_rgb": shapeless("keyboard_rgb", [mod("keyboard_full")] + glow),
        "keyboard_white": shapeless("keyboard_white", [mod("keyboard_tkl"), van("white_dye")]),
        "keyboard_black": shapeless("keyboard_black", [mod("keyboard_tkl"), van("black_dye")]),
        "keyboard_transparent": shapeless("keyboard_transparent", [mod("keyboard_tkl"), van("glass")]),
        "mousepad_black": shaped("mousepad_black", ["CCC"], {"C": van("black_carpet")}),
        "mousepad_white": shaped("mousepad_white", ["CCC"], {"C": van("white_carpet")}),
        "mousepad_red": shaped("mousepad_red", ["CCC"], {"C": van("red_carpet")}),
        "mousepad_blue": shaped("mousepad_blue", ["CCC"], {"C": van("blue_carpet")}),
        "mousepad_purple": shaped("mousepad_purple", ["CCC"], {"C": van("purple_carpet")}),
        "mousepad_rgb": shapeless("mousepad_rgb", [mod("mousepad_black")] + glow),
        "desk_wooden": shaped("desk_wooden", ["PPP", "S S"], {"P": van("oak_planks"), "S": van("stick")}),
        "desk_black": shaped("desk_black", ["WWW", "I I"], {"W": van("black_wool"), "I": van("iron_ingot")}),
        "desk_white": shaped("desk_white", ["WWW", "I I"], {"W": van("white_wool"), "I": van("iron_ingot")}),
        "desk_rgb": shapeless("desk_rgb", [mod("desk_black")] + glow),
        "monitor_24": shaped("monitor_24", ["GGG", "GRG", "III"],
                             {"G": van("glass_pane"), "R": van("redstone"), "I": van("iron_ingot")}),
        "monitor_27": shapeless("monitor_27", [mod("monitor_24"), van("glass_pane"), van("iron_ingot")]),
        "monitor_32": shapeless("monitor_32", [mod("monitor_27"), van("glass_pane"), van("iron_ingot")]),
        "monitor_curved": shapeless("monitor_curved",
                                    [mod("monitor_27"), van("amethyst_shard"), van("glass_pane")]),
        "monitor_ultrawide": shapeless("monitor_ultrawide",
                                       [mod("monitor_32"), van("amethyst_shard"), van("glass_pane")]),
        "headset": shaped("headset", ["III", "W W"], {"I": van("iron_ingot"), "W": van("black_wool")}),
        "headset_stand": shaped("headset_stand", ["I", "I", "S"],
                                {"I": van("iron_ingot"), "S": van("smooth_stone_slab")}),
        "microphone": shaped("microphone", ["B", "I", "S"],
                             {"B": van("iron_bars"), "I": van("iron_ingot"), "S": van("smooth_stone_slab")}),
        "speaker": shaped("speaker", ["III", "INI", "III"], {"I": van("iron_ingot"), "N": van("note_block")}),
        "desk_lamp": shaped("desk_lamp", ["L", "I", "S"],
                            {"L": van("redstone_lamp"), "I": van("iron_ingot"), "S": van("smooth_stone_slab")}),
        "controller": shaped("controller", ["BIB", "III"], {"B": van("stone_button"), "I": van("iron_ingot")}),
        **{n: f() for n, f in PC_RECIPES.items()},
        **{n: f() for n, f in COS_RECIPES.items()},
    }
    return r


# ---- V1.2: PC cases + prebuilt PCs ----------------------------------------------
PC_FRAMES = 48   # fan period = 16 frames (3 blades), colour cycle = 48 frames
PC_SS = 4        # supersampling factor for the PC textures

# north-facing bounding boxes (x1, y1, z1, x2, y2, z2); MUST match the PC_* boxes in ModBlocks.java
PC_SHAPES = {
    "mini": (4, 0, 3, 12, 9, 13),
    "mid": (4, 0, 1, 12, 15, 15),
    "panoramic": (3.5, 0, 1.5, 12.5, 14, 14.5),
    "full": (3, 0, 0.5, 13, 16, 15.5),
    "fish": (1, 0, 3, 15, 13, 13),
    "vertical": (5.5, 0, 1, 10.5, 16, 15),
}

# rgb modes: ("none",) | ("rainbow",) | ("fixed", hue) | ("range", hue_a, hue_b)
PC_DEFS = {
    "pc_mini_starter": dict(shape="mini", panel="#2b2e36", side="solid", front="mesh",
                            rgb=("none",), gpu_fans=0, aio=False),
    "pc_budget_gamer": dict(shape="mid", panel="#20232b", side="glass", front="mesh",
                            rgb=("fixed", 0.60), gpu_fans=2, aio=False),
    "pc_stealth": dict(shape="mid", panel="#0f1014", side="solid", front="solid",
                       rgb=("none",), gpu_fans=0, aio=False),
    "pc_white_gaming": dict(shape="mid", panel="#e6e8ee", side="glass", front="mesh",
                            rgb=("rainbow",), gpu_fans=3, aio=False),
    "pc_wood": dict(shape="mid", panel="wood", side="glass", front="wood",
                    rgb=("fixed", 0.09), gpu_fans=2, aio=False),
    "pc_snow": dict(shape="panoramic", panel="#f2f6ff", side="glass", front="glass",
                    rgb=("fixed", 0.55), gpu_fans=3, aio=False),
    "pc_neon": dict(shape="panoramic", panel="#17102a", side="glass", front="glass",
                    rgb=("range", 0.50, 0.92), gpu_fans=3, aio=False),
    "pc_panoramic": dict(shape="panoramic", panel="#1b1d24", side="glass", front="glass",
                         rgb=("rainbow",), gpu_fans=3, aio=False),
    "pc_high_end": dict(shape="full", panel="#15171c", side="glass", front="mesh",
                        rgb=("rainbow",), gpu_fans=3, aio=True),
    "pc_red_beast": dict(shape="full", panel="#1c0c0f", side="glass", front="mesh",
                         rgb=("fixed", 0.0), gpu_fans=3, aio=True),
    "pc_fish_tank": dict(shape="fish", panel="#18202c", side="glass", front="glass",
                         rgb=("range", 0.45, 0.62), gpu_fans=3, aio=True, water=True),
    "pc_vertical": dict(shape="vertical", panel="#23262d", side="glass", front="solid",
                        rgb=("range", 0.70, 0.85), gpu_fans=2, aio=False),
    "pc_mini_beast": dict(shape="mini", panel="#1f2128", side="glass", front="mesh",
                          rgb=("fixed", 0.07), gpu_fans=2, aio=False),
}


def pc_rgbq(mode, phase, t, on):
    """Colour of an RGB ring / strip. phase: position offset (0..1), t: time in the cycle (0..1)."""
    kind = mode[0]
    if not on or kind == "none":
        return (58, 60, 68, 255) if kind != "none" or not on else (86, 90, 100, 255)
    if kind == "rainbow":
        return hue_color(phase + t, 1.0, 0.9)
    if kind == "fixed":
        v = 0.8 + 0.2 * math.sin(2 * math.pi * (t + phase))
        return hue_color(mode[1], v, 0.85)
    k = 0.5 + 0.5 * math.sin(2 * math.pi * (phase + t))  # range
    return hue_color(mode[1] + (mode[2] - mode[1]) * k, 1.0, 0.9)


def pc_fan(d, cx, cy, r, ang, ring, on, blades=3):
    s = PC_SS
    cx, cy, r = cx * s, cy * s, r * s
    pad = 0.6 * s
    d.rectangle((cx - r - pad, cy - r - pad, cx + r + pad, cy + r + pad), fill=(22, 23, 28, 255))
    inner = (8, 9, 12, 255)
    if on and max(ring[:3]) - min(ring[:3]) > 40:   # coloured RGB: the fan opening glows with the ring colour
        inner = tuple(int(8 + (ring[i] - 8) * 0.30) for i in range(3)) + (255,)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=inner, outline=ring, width=max(1, s // 2))
    blade = (122, 128, 142, 255) if on else (52, 55, 63, 255)
    tip = r - 0.7 * s
    for k in range(blades):
        a = math.radians(ang + k * 360.0 / blades)
        b = a + math.radians(70)
        d.polygon([(cx, cy), (cx + math.cos(a) * tip, cy + math.sin(a) * tip),
                   (cx + math.cos(b) * tip, cy + math.sin(b) * tip)], fill=blade)
    d.ellipse((cx - 0.8 * s, cy - 0.8 * s, cx + 0.8 * s, cy + 0.8 * s), fill=(30, 32, 38, 255))


def pc_glass_shine(img, alpha):
    w, h = img.size
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    d.polygon([(w * 0.55, 0), (w * 0.80, 0), (w * 0.30, h), (w * 0.05, h)], fill=(255, 255, 255, alpha))
    d.polygon([(w * 0.86, 0), (w * 0.92, 0), (w * 0.42, h), (w * 0.36, h)], fill=(255, 255, 255, alpha // 2))
    return Image.alpha_composite(img, ov)


def pc_side_frame(df, k, on):
    """Glass side panel: the inside of the case (32x32). The case front is on the right."""
    S, W = PC_SS, 32
    t = k / float(PC_FRAMES)
    ang = k * 7.5 if on else 0.0
    mode = df["rgb"]
    water = df.get("water", False)
    top_c, bot_c = ((10, 44, 64), (5, 22, 36)) if water else ((16, 18, 25), (8, 9, 12))
    img = Image.new("RGBA", (W * S, W * S))
    d = ImageDraw.Draw(img)
    for y in range(W * S):
        f = y / float(W * S)
        d.line((0, y, W * S, y), fill=tuple(int(top_c[i] + (bot_c[i] - top_c[i]) * f) for i in range(3)) + (255,))

    def R(x1, y1, x2, y2, fill, outline=None):
        d.rectangle((x1 * S, y1 * S, x2 * S, y2 * S), fill=fill, outline=outline, width=max(1, S // 4))

    def ring(ph):
        return pc_rgbq(mode, ph, t, on)

    R(6, 3, 24, 23, (24, 34, 38))                                    # motherboard
    for i in range(16):                                              # circuit traces
        R(7 + (i * 7) % 16, 4 + (i * 5) % 18, 8.6 + (i * 7) % 16, 4.35 + (i * 5) % 18, (58, 92, 98))
    R(1, 25, 27, 31, (30, 32, 38))                                   # PSU shroud
    R(1, 25, 27, 25.5, ring(0.5))
    if df["aio"]:                                                    # liquid cooling: radiator + pump
        R(8, 1, 26, 4.6, (24, 26, 32), outline=(48, 52, 62))
        pc_fan(d, 12.5, 2.8, 1.5, ang, ring(0.10), on)
        pc_fan(d, 21.5, 2.8, 1.5, ang + 40, ring(0.35), on)
        R(9, 7, 14.5, 12.5, (20, 22, 28), outline=ring(0.7))
    else:                                                            # air cooler: heatsink + fan
        R(8, 5, 14, 14, (96, 101, 113), outline=(60, 64, 74))
        for x in range(9, 14):
            R(x, 5.4, x + 0.4, 13.6, (70, 74, 86))
        pc_fan(d, 11, 9.5, 2.4, ang, ring(0.0), on)
    for i in range(4):                                               # RAM sticks
        x = 16 + i * 1.6
        R(x, 5, x + 1.1, 12, (35, 38, 46))
        R(x, 5, x + 1.1, 6.4, ring(0.2 + i * 0.12))
    gf = df["gpu_fans"]                                              # graphics card
    R(7, 17, 25, 22.5, (38, 41, 50), outline=(68, 72, 84))
    R(7, 16.5, 25, 17.0, ring(0.25))
    pos = {0: [], 2: [(11.5, 19.8), (20.5, 19.8)], 3: [(10.5, 19.8), (16, 19.8), (21.5, 19.8)]}[gf]
    for i, (x, y) in enumerate(pos):
        pc_fan(d, x, y, 2.2, ang + i * 30, ring(0.30 + i * 0.10), on)
    pc_fan(d, 28.6, 7.5, 2.8, ang, ring(0.8), on)                    # front intake fans
    pc_fan(d, 28.6, 16.5, 2.8, ang + 20, ring(0.9), on)
    pc_fan(d, 3.6, 8.5, 2.6, ang + 10, ring(0.0), on)                # rear exhaust fan
    if water:                                                        # fish tank: rising bubbles
        for i in range(9):
            bx = (i * 11 + 5) % 28 + 2
            by = 31 - ((i * 7 + k * (64.0 / PC_FRAMES)) % 32)
            r = 0.5 + (i % 3) * 0.3
            d.ellipse(((bx - r) * S, (by - r) * S, (bx + r) * S, (by + r) * S),
                      outline=(170, 230, 245, 255), width=max(1, S // 4))
    img = pc_glass_shine(img, 14 if on else 10)
    ImageDraw.Draw(img).rectangle((0, 0, W * S - 1, W * S - 1), outline=(6, 7, 9, 255), width=S)
    if not on:
        img = Image.alpha_composite(img, Image.new("RGBA", img.size, (0, 0, 0, 70)))
    return img.resize((W, W), Image.BOX)


def pc_base_color(df):
    return hexc("#a8763e") if df["panel"] == "wood" else hexc(df["panel"])


def pc_front_frame(df, k, on):
    """Front of the case (16x16): mesh + fan, glass + fans, plain panel or wood slats."""
    S, W = PC_SS, 16
    t = k / float(PC_FRAMES)
    ang = k * 7.5 if on else 0.0
    mode = df["rgb"]
    base = pc_base_color(df)
    style = df["front"]
    img = Image.new("RGBA", (W * S, W * S), (13, 14, 18, 255))
    d = ImageDraw.Draw(img)

    def R(x1, y1, x2, y2, fill, outline=None):
        d.rectangle((x1 * S, y1 * S, x2 * S, y2 * S), fill=fill, outline=outline, width=max(1, S // 4))

    def ring(ph):
        return pc_rgbq(mode, ph, t, on)

    if style == "mesh":
        pc_fan(d, 8, 8.5, 5.2, ang, ring(0.0), on)
        ov = Image.new("RGBA", img.size, (0, 0, 0, 0))
        od = ImageDraw.Draw(ov)
        for i in range(0, W * 2):                                    # mesh grid
            od.line((i * S / 2, 0, i * S / 2, W * S), fill=(0, 0, 0, 120), width=max(1, S // 4))
            od.line((0, i * S / 2, W * S, i * S / 2), fill=(0, 0, 0, 120), width=max(1, S // 4))
        img = Image.alpha_composite(img, ov)
        d = ImageDraw.Draw(img)
        d.rectangle((0, 0, W * S - 1, W * S - 1), outline=base, width=S)
    elif style == "glass":
        pc_fan(d, 8, 4.8, 3.6, ang, ring(0.0), on)
        pc_fan(d, 8, 11.6, 3.6, ang + 20, ring(0.5), on)
        img = pc_glass_shine(img, 12 if on else 8)
        d = ImageDraw.Draw(img)
        d.rectangle((0, 0, W * S - 1, W * S - 1), outline=base, width=S)
    elif style == "wood":
        wood = wood_texture(hexc("#a8763e"), hexc("#6f4a24"), 9).resize((W * S, W * S), Image.BILINEAR)
        img = wood
        d = ImageDraw.Draw(img)
        for x in (3, 6, 10, 13):                                     # slat gaps
            R(x, 0, x + 0.3, 16, (70, 44, 20, 255))
        R(7.4, 2, 8.6, 14, ring(0.0) if on else (60, 40, 20, 255))   # glowing strip
    else:                                                            # solid
        img = Image.new("RGBA", (W * S, W * S), base)
        d = ImageDraw.Draw(img)
        for i in range(3):                                           # vent slits
            R(3, 10 + i * 1.6, 13, 10.6 + i * 1.6, shade(base, -40))
        led = (80, 255, 160, 255) if on else (60, 64, 72, 255)
        d.ellipse((11.6 * S, 2.6 * S, 12.8 * S, 3.8 * S), fill=led)
    if not on:
        img = Image.alpha_composite(img, Image.new("RGBA", img.size, (0, 0, 0, 55)))
    return img.resize((W, W), Image.BOX)


def _anim_meta(name):
    write_json(os.path.join(TEX_DIR, name + ".png.mcmeta"),
               {"animation": {"frametime": 1, "interpolate": False}})


def make_pc_textures():
    # power button (small cube on the front, top)
    for on in (False, True):
        im = Image.new("RGBA", (16, 16), (28, 29, 34, 255))
        d = ImageDraw.Draw(im)
        col = (90, 255, 190, 255) if on else (92, 96, 106, 255)
        d.ellipse((4, 4, 11, 11), outline=col, width=1)
        d.line((7, 3, 7, 7), fill=col, width=1)
        save_tex("pc_btn_on" if on else "pc_btn_off", im)

    for idx, (name, df) in enumerate(PC_DEFS.items()):
        base = pc_base_color(df)
        # panel (the plain side, bottom)
        if df["panel"] == "wood":
            panel = wood_texture(hexc("#a8763e"), hexc("#6f4a24"), 7).resize((32, 32), Image.NEAREST)
        else:
            panel = noisy(16, base, 4, idx + 100)
            ImageDraw.Draw(panel).rectangle((0, 0, 15, 15), outline=shade(base, -18))
        save_tex(name + "_panel", panel)
        # top: vent slots
        top = noisy(16, shade(base, -6), 3, idx + 200)
        td = ImageDraw.Draw(top)
        for i in range(5):
            td.rectangle((3, 3 + i * 2, 12, 3 + i * 2), fill=shade(base, -45))
        save_tex(name + "_top", top)
        # back: PSU, rear fan, IO shield, slots
        back = noisy(16, shade(base, -10), 3, idx + 300)
        bd = ImageDraw.Draw(back)
        dark = shade(base, -60)
        bd.rectangle((1, 1, 6, 6), fill=dark)
        for i, c in enumerate(((90, 200, 120), (230, 90, 90), (90, 140, 230), (230, 200, 90))):
            bd.point((2 + i, 3), fill=(c[0], c[1], c[2], 255))
        bd.ellipse((8, 1, 14, 7), fill=dark)
        for i in range(5):
            bd.rectangle((1 + i * 3, 8, 2 + i * 3, 10), fill=shade(base, -35))
        bd.ellipse((4, 11, 11, 15), fill=dark, outline=shade(base, -80))
        save_tex(name + "_back", back)
        # glass side
        if df["side"] == "glass":
            save_tex(name + "_side_off", pc_side_frame(df, 0, False))
            sheet = Image.new("RGBA", (32, 32 * PC_FRAMES))
            for k in range(PC_FRAMES):
                sheet.paste(pc_side_frame(df, k, True), (0, k * 32))
            save_tex(name + "_side_on", sheet)
            _anim_meta(name + "_side_on")
        # front
        save_tex(name + "_front_off", pc_front_frame(df, 0, False))
        sheet = Image.new("RGBA", (16, 16 * PC_FRAMES))
        for k in range(PC_FRAMES):
            sheet.paste(pc_front_frame(df, k, True), (0, k * 16))
        save_tex(name + "_front_on", sheet)
        _anim_meta(name + "_front_on")


def gen_pc_models():
    out = {}
    for name, df in PC_DEFS.items():
        x1, y1, z1, x2, y2, z2 = PC_SHAPES[df["shape"]]
        cx = (x1 + x2) / 2.0
        for on in (False, True):
            suf = "on" if on else "off"
            side = "%s_side_%s" % (name, suf) if df["side"] == "glass" else name + "_panel"
            tx = {"front": "%s_front_%s" % (name, suf), "side": side, "panel": name + "_panel",
                  "top": name + "_top", "back": name + "_back",
                  "btn": "pc_btn_on" if on else "pc_btn_off", "foot": "rubber"}
            body = {"from": [x1, 0.8, z1], "to": [x2, y2, z2], "faces": {
                "north": {"texture": "#front"}, "south": {"texture": "#back"},
                "east": {"texture": "#side"}, "west": {"texture": "#panel"},
                "up": {"texture": "#top"}, "down": {"texture": "#panel"}}}
            els = [body]
            for fx in (x1 + 0.6, x2 - 2.0):                          # four feet
                for fz in (z1 + 0.6, z2 - 2.0):
                    els.append(box_all((round(fx, 2), 0, round(fz, 2)), (round(fx + 1.4, 2), 0.8, round(fz + 1.4, 2)), "foot"))
            els.append(box_all((round(cx - 0.9, 2), round(y2 - 2.2, 2), round(z1 - 0.5, 2)),
                               (round(cx + 0.9, 2), round(y2 - 0.6, 2), z1), "btn"))   # power button
            scale = 0.7 if y2 >= 15 else 0.9
            out[name + "_" + suf] = model_json(tx, els, scale, cy=y2 / 2.0)
    return out


def pc_blockstate(name):
    variants = {}
    for facing, y in ROT.items():
        for lit in (False, True):
            entry = {"model": "%s:block/%s_%s" % (MODID, name, "on" if lit else "off")}
            if y:
                entry["y"] = y
            variants["facing=%s,lit=%s" % (facing, str(lit).lower())] = entry
    return {"variants": variants}


PC_RECIPES = {
    "pc_mini_starter": lambda: shaped("pc_mini_starter", ["III", "IRI", "III"],
                                      {"I": van("iron_ingot"), "R": van("redstone")}),
    "pc_budget_gamer": lambda: shapeless("pc_budget_gamer",
                                         [mod("pc_mini_starter"), van("iron_ingot"), van("iron_ingot"), van("redstone")]),
    "pc_stealth": lambda: shapeless("pc_stealth", [mod("pc_budget_gamer"), van("black_dye"), van("black_wool")]),
    "pc_white_gaming": lambda: shapeless("pc_white_gaming",
                                         [mod("pc_budget_gamer"), van("white_dye"), van("glass_pane"), van("glowstone_dust")]),
    "pc_wood": lambda: shapeless("pc_wood", [mod("pc_budget_gamer"), van("oak_planks"), van("oak_planks")]),
    "pc_vertical": lambda: shapeless("pc_vertical", [mod("pc_budget_gamer"), van("iron_ingot"), van("glass_pane")]),
    "pc_mini_beast": lambda: shapeless("pc_mini_beast",
                                       [mod("pc_mini_starter"), van("diamond"), van("glowstone_dust"), van("redstone")]),
    "pc_panoramic": lambda: shapeless("pc_panoramic",
                                      [mod("pc_white_gaming"), van("glass"), van("glass"), van("amethyst_shard")]),
    "pc_snow": lambda: shapeless("pc_snow", [mod("pc_panoramic"), van("snow_block"), van("glowstone_dust")]),
    "pc_neon": lambda: shapeless("pc_neon", [mod("pc_panoramic"), van("pink_dye"), van("light_blue_dye")]),
    "pc_high_end": lambda: shapeless("pc_high_end",
                                     [mod("pc_budget_gamer"), van("diamond"), van("glass"), van("glowstone_dust")]),
    "pc_red_beast": lambda: shapeless("pc_red_beast", [mod("pc_high_end"), van("red_dye"), van("redstone_block")]),
    "pc_fish_tank": lambda: shapeless("pc_fish_tank", [mod("pc_panoramic"), van("glass"), van("tropical_fish")]),
}


# ---- V1.2.1: cosmetics (creator plaques, mug, energy can, cactus, rubber duck) ------
COS_SS = 4

# creator award plaques: name -> (base, dark, light, label). Generic design, NOT a branded logo.
PLAQUES = {
    "plaque_silver": ("#c3c9d4", "#7d8594", "#eef1f6", "100K"),
    "plaque_gold": ("#e8b93a", "#9a6f12", "#fbe58a", "1M"),
    "plaque_diamond": ("#6fd0f2", "#2a7fa6", "#d8f6ff", "10M"),
}


def cos_font(size):
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def lerp_color(a, b, f):
    return tuple(int(a[i] + (b[i] - a[i]) * f) for i in range(3)) + (255,)


def plaque_front(base, dark, light, label):
    S, W = COS_SS, 32
    base, dark, light = hexc(base), hexc(dark), hexc(light)
    img = Image.new("RGBA", (W * S, W * S), dark)
    d = ImageDraw.Draw(img)
    b = 2 * S
    d.polygon([(0, 0), (W * S, 0), (W * S - b, b), (b, b), (b, W * S - b), (0, W * S)], fill=light)   # bevel
    for y in range(b, W * S - b):                                     # brushed gradient panel
        f = (y - b) / float(W * S - 2 * b)
        d.line((b, y, W * S - b - 1, y), fill=lerp_color(lerp_color(light, base, 0.55), dark, f * 0.55))
    rnd = random.Random(11)
    for _ in range(90):                                               # brushed streaks
        y = rnd.randint(b, W * S - b - 1)
        x = rnd.randint(b, W * S - b - 40)
        d.line((x, y, x + rnd.randint(10, 40), y), fill=(255, 255, 255, 28))
    d.rectangle((4 * S, 4 * S, W * S - 4 * S, W * S - 4 * S), outline=dark, width=max(1, S // 2))      # engraved frame
    cx, cy, r = 16 * S, 12.5 * S, 7 * S                               # medallion with a generic play symbol
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=dark, outline=light, width=max(1, S // 2))
    d.polygon([(13.6 * S, 8.6 * S), (13.6 * S, 16.4 * S), (20.2 * S, 12.5 * S)], fill=light)
    f = cos_font(int(5.4 * S))
    tw = d.textlength(label, font=f)
    ink = tuple(int(c * 0.55) for c in dark[:3]) + (255,)
    d.text(((W * S - tw) / 2, 21.2 * S), label, font=f, fill=ink)
    return img.resize((W, W), Image.BOX)


def make_cosmetic_textures():
    for name, (base, dark, light, label) in PLAQUES.items():
        kind = name.split("_")[1]
        save_tex(name + "_front", plaque_front(base, dark, light, label))
        save_tex("plaque_metal_" + kind, noisy(16, hexc(base), 4, len(kind)))
    save_tex("plaque_stand", noisy(16, hexc("#26282f"), 4, 61))

    mug = noisy(16, hexc("#f1f1f5"), 3, 62)
    ImageDraw.Draw(mug).rectangle((0, 6, 15, 8), fill=hexc("#3a78d8"))
    save_tex("mug_body", mug)
    coffee = noisy(16, hexc("#5a3720"), 5, 63)
    ImageDraw.Draw(coffee).ellipse((4, 4, 11, 11), fill=hexc("#6e4528"))
    save_tex("mug_coffee", coffee)

    can = noisy(16, hexc("#181a1e"), 3, 64)
    cd = ImageDraw.Draw(can)
    cd.polygon([(0, 11), (6, 4), (9, 8), (15, 2), (15, 6), (9, 12), (6, 8), (0, 15)], fill=hexc("#5af03c"))
    cd.rectangle((0, 0, 15, 1), fill=hexc("#b7bcc6"))
    cd.rectangle((0, 14, 15, 15), fill=hexc("#b7bcc6"))
    save_tex("can_side", can)
    cap = noisy(16, hexc("#b7bcc6"), 4, 65)
    ImageDraw.Draw(cap).ellipse((3, 3, 12, 12), outline=hexc("#8a909c"))
    save_tex("can_top", cap)

    cactus = noisy(16, hexc("#3f9a4c"), 5, 66)
    kd = ImageDraw.Draw(cactus)
    for x in (3, 7, 11):
        kd.line((x, 0, x, 15), fill=hexc("#2c7438"))
    for (x, y) in ((1, 3), (5, 9), (9, 4), (13, 11), (6, 1), (12, 7)):
        kd.point((x, y), fill=hexc("#f3efc2"))
    save_tex("cactus", cactus)
    pot = noisy(16, hexc("#b45c3a"), 5, 67)
    ImageDraw.Draw(pot).rectangle((0, 0, 15, 3), fill=hexc("#c9714c"))
    save_tex("pot", pot)
    save_tex("soil", noisy(16, hexc("#4a3020"), 6, 68))

    save_tex("duck_body", noisy(16, hexc("#fad634"), 5, 69))
    face = noisy(16, hexc("#fad634"), 5, 70)
    fd = ImageDraw.Draw(face)
    fd.rectangle((3, 5, 4, 6), fill=hexc("#15151a"))
    fd.rectangle((11, 5, 12, 6), fill=hexc("#15151a"))
    save_tex("duck_face", face)
    save_tex("duck_beak", noisy(16, hexc("#f08a1e"), 4, 71))


def gen_cosmetic_models():
    out = {}
    for name in PLAQUES:
        kind = name.split("_")[1]
        tx = {"front": name + "_front", "metal": "plaque_metal_" + kind, "stand": "plaque_stand"}
        plate = {"from": [3.5, 1.4, 7.6], "to": [12.5, 11, 8.8], "faces": {
            "north": {"texture": "#front"}, "south": {"texture": "#metal"},
            "east": {"texture": "#metal"}, "west": {"texture": "#metal"},
            "up": {"texture": "#metal"}, "down": {"texture": "#metal"}}}
        els = [box_all((4.5, 0, 6.6), (11.5, 1.4, 9.4), "stand"), plate,
               box_all((6.5, 1.4, 8.8), (9.5, 7, 9.4), "stand")]
        out[name] = model_json(tx, els, 1.3, cy=5.5)

    out["coffee_mug"] = model_json(
        {"mug": "mug_body", "coffee": "mug_coffee"},
        [box_top((5.5, 0, 5.5), (9.5, 4.5, 9.5), "coffee", "mug"),
         box_all((9.5, 1, 7.2), (10.6, 3.6, 8.2), "mug")], 2.2, cy=2.2)
    out["energy_can"] = model_json(
        {"can": "can_side", "top": "can_top"},
        [box_top((6.2, 0, 6.2), (9.8, 6, 9.8), "top", "can")], 2.0, cy=3.0)
    out["desk_plant"] = model_json(
        {"pot": "pot", "soil": "soil", "cactus": "cactus"},
        [box_top((5.5, 0, 5.5), (10.5, 3.4, 10.5), "soil", "pot"),
         box_all((7, 3.4, 7), (9, 9, 9), "cactus"),
         box_all((5.6, 5, 7.5), (7, 6, 8.5), "cactus"), box_all((5.6, 6, 7.5), (6.6, 7.8, 8.5), "cactus"),
         box_all((9, 6, 7.5), (10.4, 7, 8.5), "cactus"), box_all((9.4, 7, 7.5), (10.4, 8.4, 8.5), "cactus")],
        1.8, cy=4.5)
    head = {"from": [6.5, 3.4, 4.8], "to": [9.5, 6.6, 8], "faces": {
        "north": {"texture": "#face"}, "south": {"texture": "#duck"}, "east": {"texture": "#duck"},
        "west": {"texture": "#duck"}, "up": {"texture": "#duck"}, "down": {"texture": "#duck"}}}
    out["rubber_duck"] = model_json(
        {"duck": "duck_body", "face": "duck_face", "beak": "duck_beak"},
        [box_all((5.5, 0, 4.8), (10.5, 3.4, 10.6), "duck"), head,
         box_all((7.1, 4.0, 3.9), (8.9, 5.0, 4.8), "beak"),
         box_all((7.2, 2.6, 10.2), (8.8, 4.4, 11.4), "duck")], 2.0, cy=3.3)
    return out


COS_RECIPES = {
    "plaque_silver": lambda: shaped("plaque_silver", ["III", "IBI", "III"],
                                    {"I": van("iron_ingot"), "B": van("stone_button")}),
    "plaque_gold": lambda: shaped("plaque_gold", ["III", "IBI", "III"],
                                  {"I": van("gold_ingot"), "B": van("stone_button")}),
    "plaque_diamond": lambda: shapeless("plaque_diamond", [mod("plaque_gold"), van("diamond"), van("diamond")]),
    "coffee_mug": lambda: shaped("coffee_mug", ["TT", "TT"], {"T": van("white_terracotta")}),
    "energy_can": lambda: shaped("energy_can", ["N", "D", "N"], {"N": van("iron_nugget"), "D": van("lime_dye")}),
    "desk_plant": lambda: shaped("desk_plant", ["C", "P"], {"C": van("cactus"), "P": van("flower_pot")}),
    "rubber_duck": lambda: shapeless("rubber_duck", [van("yellow_dye"), van("orange_dye"), van("slime_ball")]),
}


# --------------------------------------------------------------------------- main
def main():
    for d in (TEX_DIR, os.path.join(ASSETS, "models"), os.path.join(ASSETS, "blockstates"), DATA):
        if os.path.isdir(d):
            shutil.rmtree(d)

    make_plain_textures()
    make_honeycomb()
    make_keyboard_textures()
    make_pad_textures()
    make_desk_textures()
    make_v11_textures()
    make_wallpaper_textures()
    make_pc_textures()
    make_cosmetic_textures()

    models = {}
    models.update(gen_mouse_models())
    models.update(gen_keyboard_models())
    models.update(gen_pad_models())
    models.update(gen_desk_models())
    models.update(gen_mouse_onpad_models())
    models.update(gen_monitor_models())
    models.update(gen_accessory_models())
    models.update(gen_pc_models())
    models.update(gen_cosmetic_models())

    for mname, mjson in models.items():
        write_json(os.path.join(ASSETS, "models", "block", mname + ".json"), mjson)

    lang = {"itemGroup." + MODID: "Realistic Gaming Gear"}
    for name in ALL_NAMES:
        rgb = name in RGB_NAMES
        is_desk = name.startswith("desk_")
        if name.startswith("mousepad_"):
            state = pad_blockstate(name, rgb)
        elif name.startswith("monitor_"):
            state = monitor_blockstate(name)
        elif name.startswith("pc_"):
            state = pc_blockstate(name)
        else:
            state = blockstate(name, rgb, has_facing=not is_desk)
        write_json(os.path.join(ASSETS, "blockstates", name + ".json"), state)
        item_parent = name + ("_wp1" if name.startswith("monitor_") else "_on" if name.startswith("pc_") else "_lit" if rgb else "")
        write_json(os.path.join(ASSETS, "models", "item", name + ".json"),
                   {"parent": "%s:block/%s" % (MODID, item_parent)})
        loot = pad_loot(name) if name.startswith("mousepad_") else loot_table(name)
        write_json(os.path.join(DATA, "loot_tables", "blocks", name + ".json"), loot)
        lang["block.%s.%s" % (MODID, name)] = NICE[name]

    write_json(os.path.join(ASSETS, "lang", "en_us.json"), lang)

    for name, rj in recipes().items():
        write_json(os.path.join(DATA, "recipes", name + ".json"), rj)

    print("textures: %d, models: %d, blocks: %d" % (len(textures_made), len(models), len(ALL_NAMES)))


if __name__ == "__main__":
    main()
