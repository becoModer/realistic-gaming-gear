package com.realisticgaminggear.registry;

import com.realisticgaminggear.RealisticGamingGear;
import com.realisticgaminggear.block.DeskBlock;
import com.realisticgaminggear.block.GearBlock;
import com.realisticgaminggear.block.MonitorBlock;
import com.realisticgaminggear.block.MousePadBlock;
import com.realisticgaminggear.block.PcBlock;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * All blocks and their block items. The names here must match the generated
 * blockstates / models / textures (see the tools/ folder).
 */
public final class ModBlocks {
    private static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, RealisticGamingGear.MODID);
    private static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RealisticGamingGear.MODID);

    /** Items in creative tab order. */
    public static final List<RegistryObject<Item>> TAB_ITEMS = new ArrayList<>();

    // ---- box = {x1, y1, z1, x2, y2, z2} in 1/16 block units, facing north ----
    private static final double[] MOUSE = {6, 0, 5, 10, 2.2, 11};
    private static final double[] KB_60 = {2, 0, 5, 14, 1.6, 11};
    private static final double[] KB_65 = {1.5, 0, 5, 14.5, 1.6, 11};
    private static final double[] KB_TKL = {0.5, 0, 4.5, 15.5, 1.6, 11.5};
    private static final double[] KB_FULL = {0, 0, 4, 16, 1.6, 12};
    private static final double[] KB_CUSTOM = {1, 0, 5, 15, 2, 11};

    private static final double[] MON_24 = {3, 0, 6, 13, 8.5, 10};
    private static final double[] MON_27 = {2, 0, 6, 14, 10, 10};
    private static final double[] MON_32 = {1, 0, 6, 15, 11.5, 10};
    private static final double[] MON_CURVED = {0.5, 0, 5.5, 15.5, 10, 10};
    private static final double[] MON_ULTRAWIDE = {0, 0, 6, 16, 10.5, 10};

    private static final double[] BOX_HEADSET = {2.8, 0, 6, 13.2, 4.2, 13.3};
    private static final double[] BOX_HEADSET_STAND = {3.6, 0, 5.3, 12.4, 12.3, 10.7};
    private static final double[] BOX_MICROPHONE = {6, 0, 6, 10, 10.9, 10};
    private static final double[] BOX_SPEAKER = {5, 0, 4.9, 11, 11.3, 11};
    private static final double[] BOX_DESK_LAMP = {5.5, 0, 5.5, 10.5, 11, 10.5};
    private static final double[] BOX_CONTROLLER = {4.5, 0, 5.5, 11.5, 2.2, 10};

    // ---- PC cases (north-facing boxes; must match PC_SHAPES in tools/gen_assets.py) ----
    private static final double[] PC_MINI = {4, 0, 3, 12, 9, 13};
    private static final double[] PC_MID = {4, 0, 1, 12, 15, 15};
    private static final double[] PC_PANORAMIC = {3.5, 0, 1.5, 12.5, 14, 14.5};
    private static final double[] PC_FULL = {3, 0, 0.5, 13, 16, 15.5};
    private static final double[] PC_FISH = {1, 0, 3, 15, 13, 13};
    private static final double[] PC_VERTICAL = {5.5, 0, 1, 10.5, 16, 15};

    private static final double[] BOX_PLAQUE = {3.5, 0, 6.6, 12.5, 11, 9.4};
    private static final double[] BOX_MUG = {5.5, 0, 5.5, 10.6, 4.5, 9.5};
    private static final double[] BOX_CAN = {6.2, 0, 6.2, 9.8, 6, 9.8};
    private static final double[] BOX_PLANT = {5.5, 0, 5.5, 10.5, 9, 10.5};
    private static final double[] BOX_DUCK = {5.5, 0, 3.9, 10.5, 6.6, 11.4};

    // ---- Mice ----
    public static final RegistryObject<Block> MOUSE_BASIC = gear("mouse_basic", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_RGB = gear("mouse_rgb", MOUSE, true, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_LIGHTWEIGHT = gear("mouse_lightweight", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_PRO = gear("mouse_pro", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_WIRELESS = gear("mouse_wireless", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_ULTRA = gear("mouse_ultra", MOUSE, true, Click.MOUSE);

    // ---- Keyboards ----
    public static final RegistryObject<Block> KEYBOARD_60 = gear("keyboard_60", KB_60, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_65 = gear("keyboard_65", KB_65, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_TKL = gear("keyboard_tkl", KB_TKL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_FULL = gear("keyboard_full", KB_FULL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_CUSTOM = gear("keyboard_custom", KB_CUSTOM, true, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_RGB = gear("keyboard_rgb", KB_FULL, true, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_WHITE = gear("keyboard_white", KB_TKL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_BLACK = gear("keyboard_black", KB_TKL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_TRANSPARENT = gear("keyboard_transparent", KB_TKL, false, Click.KEY);

    // ---- Mousepads (a mouse can be placed on them) ----
    public static final RegistryObject<Block> MOUSEPAD_BLACK = pad("mousepad_black", false);
    public static final RegistryObject<Block> MOUSEPAD_WHITE = pad("mousepad_white", false);
    public static final RegistryObject<Block> MOUSEPAD_RED = pad("mousepad_red", false);
    public static final RegistryObject<Block> MOUSEPAD_BLUE = pad("mousepad_blue", false);
    public static final RegistryObject<Block> MOUSEPAD_PURPLE = pad("mousepad_purple", false);
    public static final RegistryObject<Block> MOUSEPAD_RGB = pad("mousepad_rgb", true);

    // ---- Desks ----
    public static final RegistryObject<Block> DESK_WOODEN = desk("desk_wooden", false, SoundType.WOOD, MapColor.WOOD);
    public static final RegistryObject<Block> DESK_BLACK = desk("desk_black", false, SoundType.WOOD, MapColor.COLOR_BLACK);
    public static final RegistryObject<Block> DESK_WHITE = desk("desk_white", false, SoundType.WOOD, MapColor.SNOW);
    public static final RegistryObject<Block> DESK_RGB = desk("desk_rgb", true, SoundType.WOOD, MapColor.COLOR_BLACK);

    // ---- Monitors (sneak + right click = screen on/off) ----
    public static final RegistryObject<Block> MONITOR_24 = monitor("monitor_24", MON_24, 5);
    public static final RegistryObject<Block> MONITOR_27 = monitor("monitor_27", MON_27, 5);
    public static final RegistryObject<Block> MONITOR_32 = monitor("monitor_32", MON_32, 5);
    public static final RegistryObject<Block> MONITOR_CURVED = monitor("monitor_curved", MON_CURVED, 6);
    public static final RegistryObject<Block> MONITOR_ULTRAWIDE = monitor("monitor_ultrawide", MON_ULTRAWIDE, 6);

    // ---- Accessories ----
    public static final RegistryObject<Block> HEADSET = gear("headset", BOX_HEADSET, false, Click.SOFT);
    public static final RegistryObject<Block> HEADSET_STAND = gear("headset_stand", BOX_HEADSET_STAND, true, Click.MOUSE, 5);
    public static final RegistryObject<Block> MICROPHONE_BLOCK = gear("microphone", BOX_MICROPHONE, true, Click.MOUSE, 5);
    public static final RegistryObject<Block> SPEAKER_BLOCK = gear("speaker", BOX_SPEAKER, true, Click.KEY, 5);
    public static final RegistryObject<Block> DESK_LAMP = gear("desk_lamp", BOX_DESK_LAMP, true, Click.MOUSE, 14);
    public static final RegistryObject<Block> CONTROLLER_BLOCK = gear("controller", BOX_CONTROLLER, false, Click.MOUSE);

    // ---- Prebuilt gaming PCs (right click = power button, sneak + right click = rotate) ----
    public static final RegistryObject<Block> PC_MINI_STARTER = pc("pc_mini_starter", PC_MINI, 3);
    public static final RegistryObject<Block> PC_BUDGET_GAMER = pc("pc_budget_gamer", PC_MID, 5);
    public static final RegistryObject<Block> PC_STEALTH = pc("pc_stealth", PC_MID, 2);
    public static final RegistryObject<Block> PC_WHITE_GAMING = pc("pc_white_gaming", PC_MID, 7);
    public static final RegistryObject<Block> PC_WOOD = pc("pc_wood", PC_MID, 6);
    public static final RegistryObject<Block> PC_SNOW = pc("pc_snow", PC_PANORAMIC, 7);
    public static final RegistryObject<Block> PC_NEON = pc("pc_neon", PC_PANORAMIC, 8);
    public static final RegistryObject<Block> PC_PANORAMIC_BUILD = pc("pc_panoramic", PC_PANORAMIC, 8);
    public static final RegistryObject<Block> PC_HIGH_END = pc("pc_high_end", PC_FULL, 9);
    public static final RegistryObject<Block> PC_RED_BEAST = pc("pc_red_beast", PC_FULL, 9);
    public static final RegistryObject<Block> PC_FISH_TANK = pc("pc_fish_tank", PC_FISH, 8);
    public static final RegistryObject<Block> PC_VERTICAL_BUILD = pc("pc_vertical", PC_VERTICAL, 7);
    public static final RegistryObject<Block> PC_MINI_BEAST = pc("pc_mini_beast", PC_MINI, 7);

    // ---- Cosmetics ----
    public static final RegistryObject<Block> PLAQUE_SILVER = gear("plaque_silver", BOX_PLAQUE, false, Click.MOUSE);
    public static final RegistryObject<Block> PLAQUE_GOLD = gear("plaque_gold", BOX_PLAQUE, false, Click.MOUSE);
    public static final RegistryObject<Block> PLAQUE_DIAMOND = gear("plaque_diamond", BOX_PLAQUE, false, Click.MOUSE);
    public static final RegistryObject<Block> COFFEE_MUG = gear("coffee_mug", BOX_MUG, false, Click.MOUSE);
    public static final RegistryObject<Block> ENERGY_CAN = gear("energy_can", BOX_CAN, false, Click.MOUSE);
    public static final RegistryObject<Block> DESK_PLANT = gear("desk_plant", BOX_PLANT, false, Click.SOFT);
    public static final RegistryObject<Block> RUBBER_DUCK = gear("rubber_duck", BOX_DUCK, false, Click.SOFT);

    private ModBlocks() {
    }

    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
    }

    // ---- helpers ----

    private enum Click {
        MOUSE(SoundEvents.STONE_BUTTON_CLICK_ON),
        KEY(SoundEvents.WOODEN_BUTTON_CLICK_ON),
        SOFT(SoundEvents.WOOL_PLACE);

        final SoundEvent sound;

        Click(SoundEvent sound) {
            this.sound = sound;
        }
    }

    private static RegistryObject<Block> gear(String name, double[] box, boolean rgb, Click click) {
        return gear(name, box, rgb, click, 7);
    }

    /** @param glow light level while the item is lit (RGB / screen / lamp on) */
    private static RegistryObject<Block> gear(String name, double[] box, boolean rgb, Click click, int glow) {
        return block(name, () -> new GearBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.COLOR_GRAY)
                        .strength(0.4F)
                        .sound(click == Click.SOFT ? SoundType.WOOL : SoundType.STONE)
                        .noOcclusion()
                        .lightLevel(state -> rgb && state.getValue(GearBlock.LIT) ? glow : 0),
                box, rgb, click.sound));
    }

    /** @param glow light level while the screen is on */
    private static RegistryObject<Block> monitor(String name, double[] box, int glow) {
        return block(name, () -> new MonitorBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.COLOR_GRAY)
                        .strength(0.4F)
                        .sound(SoundType.STONE)
                        .noOcclusion()
                        .lightLevel(state -> state.getValue(GearBlock.LIT) ? glow : 0),
                box));
    }

    /** @param glow light level while the PC is on */
    private static RegistryObject<Block> pc(String name, double[] box, int glow) {
        return block(name, () -> new PcBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.COLOR_GRAY)
                        .strength(1.0F)
                        .sound(SoundType.METAL)
                        .noOcclusion()
                        .lightLevel(state -> state.getValue(GearBlock.LIT) ? glow : 0),
                box));
    }

    private static RegistryObject<Block> pad(String name, boolean rgb) {
        return block(name, () -> new MousePadBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.COLOR_GRAY)
                        .strength(0.4F)
                        .sound(SoundType.WOOL)
                        .noOcclusion()
                        .lightLevel(state -> state.getValue(GearBlock.LIT)
                                && (rgb || state.getValue(MousePadBlock.MOUSE).isRgb()) ? 7 : 0),
                rgb));
    }

    private static RegistryObject<Block> desk(String name, boolean rgb, SoundType sound, MapColor color) {
        return block(name, () -> new DeskBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(color)
                        .strength(1.5F, 3.0F)
                        .sound(sound)
                        .noOcclusion()
                        .lightLevel(state -> rgb && state.getValue(DeskBlock.LIT) ? 9 : 0),
                rgb));
    }

    private static RegistryObject<Block> block(String name, Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        TAB_ITEMS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties())));
        return block;
    }
}
