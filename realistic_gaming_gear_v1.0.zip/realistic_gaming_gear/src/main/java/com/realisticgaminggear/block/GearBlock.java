package com.realisticgaminggear.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A small desk item (mouse, keyboard, mousepad).
 * <p>
 * Model convention: with FACING = NORTH the "front" of the item (the edge nearest the
 * person sitting at the desk) points to the north. The item must stand on a block whose
 * top face is full (e.g. a desk).
 * <ul>
 *   <li>Right click: rotate 90 degrees and play a click sound.</li>
 *   <li>Sneak + right click: toggle RGB lighting (RGB variants only).</li>
 * </ul>
 */
public class GearBlock extends HorizontalDirectionalBlock {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    /** Indexed by {@link Direction#get2DDataValue()}. */
    private final VoxelShape[] shapes = new VoxelShape[4];
    private final boolean rgb;
    private final SoundEvent clickSound;

    /**
     * @param box north-facing box in 1/16 block units: {x1, y1, z1, x2, y2, z2}
     */
    public GearBlock(Properties properties, double[] box, boolean rgb, SoundEvent clickSound) {
        super(properties);
        this.rgb = rgb;
        this.clickSound = clickSound;

        double[] current = box.clone();
        // Clockwise steps from NORTH: NORTH 0, EAST 1, SOUTH 2, WEST 3
        Direction[] clockwise = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        for (Direction dir : clockwise) {
            shapes[dir.get2DDataValue()] = Block.box(current[0], current[1], current[2],
                    current[3], current[4], current[5]);
            current = rotateClockwise(current);
        }

        registerDefaultState(stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(LIT, rgb));
    }

    /** Rotates a box 90 degrees clockwise (seen from above) around the block centre. */
    private static double[] rotateClockwise(double[] b) {
        // (x, z) -> (16 - z, x)
        return new double[]{16 - b[5], b[1], b[0], 16 - b[2], b[4], b[3]};
    }

    public boolean isRgb() {
        return rgb;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIT);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState()
                .setValue(FACING, context.getHorizontalDirection().getOpposite())
                .setValue(LIT, rgb);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapes[state.getValue(FACING).get2DDataValue()];
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction == Direction.DOWN && !state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (player.isShiftKeyDown() && rgb) {
            boolean nowLit = !state.getValue(LIT);
            level.setBlock(pos, state.setValue(LIT, nowLit), 3);
            level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS,
                    0.6F, nowLit ? 1.2F : 0.9F);
        } else {
            level.setBlock(pos, state.setValue(FACING, state.getValue(FACING).getClockWise()), 3);
            level.playSound(null, pos, clickSound, SoundSource.BLOCKS,
                    0.5F, 0.9F + level.random.nextFloat() * 0.3F);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
