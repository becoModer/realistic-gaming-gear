package com.realisticgaminggear.registry;

import com.realisticgaminggear.RealisticGamingGear;
import com.realisticgaminggear.block.DeskBlock;
import com.realisticgaminggear.block.GearBlock;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * All blocks and their block items. The names here must match the generated
 * blockstates / models / textures (see the tools/ folder).
 */
public final class ModBlocks {
    private static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, RealisticGamingGear.MODID);
    private static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RealisticGamingGear.MODID);

    /** Items in creative tab order. */
    public static final List<RegistryObject<Item>> TAB_ITEMS = new ArrayList<>();

    // ---- box = {x1, y1, z1, x2, y2, z2} in 1/16 block units, facing north ----
    private static final double[] MOUSE = {6, 0, 5, 10, 2.2, 11};
    private static final double[] KB_60 = {2, 0, 5, 14, 1.6, 11};
    private static final double[] KB_65 = {1.5, 0, 5, 14.5, 1.6, 11};
    private static final double[] KB_TKL = {0.5, 0, 4.5, 15.5, 1.6, 11.5};
    private static final double[] KB_FULL = {0, 0, 4, 16, 1.6, 12};
    private static final double[] KB_CUSTOM = {1, 0, 5, 15, 2, 11};
    private static final double[] PAD = {1, 0, 2, 15, 1, 14};

    // ---- Mice ----
    public static final RegistryObject<Block> MOUSE_BASIC = gear("mouse_basic", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_RGB = gear("mouse_rgb", MOUSE, true, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_LIGHTWEIGHT = gear("mouse_lightweight", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_PRO = gear("mouse_pro", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_WIRELESS = gear("mouse_wireless", MOUSE, false, Click.MOUSE);
    public static final RegistryObject<Block> MOUSE_ULTRA = gear("mouse_ultra", MOUSE, true, Click.MOUSE);

    // ---- Keyboards ----
    public static final RegistryObject<Block> KEYBOARD_60 = gear("keyboard_60", KB_60, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_65 = gear("keyboard_65", KB_65, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_TKL = gear("keyboard_tkl", KB_TKL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_FULL = gear("keyboard_full", KB_FULL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_CUSTOM = gear("keyboard_custom", KB_CUSTOM, true, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_RGB = gear("keyboard_rgb", KB_FULL, true, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_WHITE = gear("keyboard_white", KB_TKL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_BLACK = gear("keyboard_black", KB_TKL, false, Click.KEY);
    public static final RegistryObject<Block> KEYBOARD_TRANSPARENT = gear("keyboard_transparent", KB_TKL, false, Click.KEY);

    // ---- Mousepads ----
    public static final RegistryObject<Block> MOUSEPAD_BLACK = gear("mousepad_black", PAD, false, Click.SOFT);
    public static final RegistryObject<Block> MOUSEPAD_WHITE = gear("mousepad_white", PAD, false, Click.SOFT);
    public static final RegistryObject<Block> MOUSEPAD_RED = gear("mousepad_red", PAD, false, Click.SOFT);
    public static final RegistryObject<Block> MOUSEPAD_BLUE = gear("mousepad_blue", PAD, false, Click.SOFT);
    public static final RegistryObject<Block> MOUSEPAD_PURPLE = gear("mousepad_purple", PAD, false, Click.SOFT);
    public static final RegistryObject<Block> MOUSEPAD_RGB = gear("mousepad_rgb", PAD, true, Click.SOFT);

    // ---- Desks ----
    public static final RegistryObject<Block> DESK_WOODEN = desk("desk_wooden", false, SoundType.WOOD, MapColor.WOOD);
    public static final RegistryObject<Block> DESK_BLACK = desk("desk_black", false, SoundType.WOOD, MapColor.COLOR_BLACK);
    public static final RegistryObject<Block> DESK_WHITE = desk("desk_white", false, SoundType.WOOD, MapColor.SNOW);
    public static final RegistryObject<Block> DESK_RGB = desk("desk_rgb", true, SoundType.WOOD, MapColor.COLOR_BLACK);

    private ModBlocks() {
    }

    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
    }

    // ---- helpers ----

    private enum Click {
        MOUSE(SoundEvents.STONE_BUTTON_CLICK_ON),
        KEY(SoundEvents.WOODEN_BUTTON_CLICK_ON),
        SOFT(SoundEvents.WOOL_PLACE);

        final SoundEvent sound;

        Click(SoundEvent sound) {
            this.sound = sound;
        }
    }

    private static RegistryObject<Block> gear(String name, double[] box, boolean rgb, Click click) {
        return block(name, () -> new GearBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.COLOR_GRAY)
                        .strength(0.4F)
                        .sound(click == Click.SOFT ? SoundType.WOOL : SoundType.STONE)
                        .noOcclusion()
                        .lightLevel(state -> rgb && state.getValue(GearBlock.LIT) ? 7 : 0),
                box, rgb, click.sound));
    }

    private static RegistryObject<Block> desk(String name, boolean rgb, SoundType sound, MapColor color) {
        return block(name, () -> new DeskBlock(
                BlockBehaviour.Properties.of()
                        .mapColor(color)
                        .strength(1.5F, 3.0F)
                        .sound(sound)
                        .noOcclusion()
                        .lightLevel(state -> rgb && state.getValue(DeskBlock.LIT) ? 9 : 0),
                rgb));
    }

    private static RegistryObject<Block> block(String name, Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        TAB_ITEMS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties())));
        return block;
    }
}
