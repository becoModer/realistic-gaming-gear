package com.realisticgaminggear.registry;

import com.realisticgaminggear.RealisticGamingGear;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    private static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RealisticGamingGear.MODID);

    public static final RegistryObject<CreativeModeTab> GEAR_TAB = TABS.register("gear",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + RealisticGamingGear.MODID))
                    .icon(() -> new ItemStack(ModBlocks.MOUSE_RGB.get()))
                    .displayItems((parameters, output) ->
                            ModBlocks.TAB_ITEMS.forEach(item -> output.accept(item.get())))
                    .build());

    private ModCreativeTabs() {
    }

    public static void register(IEventBus modBus) {
        TABS.register(modBus);
    }
}
