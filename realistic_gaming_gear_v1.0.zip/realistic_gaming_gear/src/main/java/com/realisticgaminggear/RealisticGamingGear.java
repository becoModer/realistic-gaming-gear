package com.realisticgaminggear;

import com.realisticgaminggear.registry.ModBlocks;
import com.realisticgaminggear.registry.ModCreativeTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RealisticGamingGear.MODID)
public class RealisticGamingGear {
    public static final String MODID = "realisticgaminggear";

    public RealisticGamingGear() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.register(modBus);
        ModCreativeTabs.register(modBus);
    }
}
